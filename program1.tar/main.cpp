// Channer Bok main file Program 2



#include"node.h"

int main()
{
  // Introduction
  cout << "\nWelcome to the Relief Effort Directory!"
       << "\nThis program organizes relief efforts for those"
       << "\nin a time of need. There are two functionalities"
       << "\nto the program, one allows the user to add donations"
       << "\nto the program and another allows a user to select"
       << "\navailible options for their receiving their own relief efforts."
       << endl;

  // Calls menu Function
  main_menu();

  // End of Program
  cout << "\nThank you for using Relief Effort Directory! Goodbeye." << endl;
  return 0;
}



// Menu Function for entire program
void main_menu()
{
  // Variables
  int main_selection;       // Main Menu Option Choice
  int effort_selection;     // Relief Effort Menu Choice

  int search_selection = 0; // Search History Menu Choice
  int search_retrieval = 0; // Catches Search History Retrieval function Result
  int retrieval_results = 0;

  int housing_selection = 0;    // Housing Menu Option Choice
  int clothing_selection = 0;   // Clothing Menu Option Choice
  int provisions_selection = 0; // Provisions Menu Option Choice

  int cll_result;               // Results From 

  int retrieve_flag_h = 0;      // Housing Retrieval Results
  int retrieve_flag_p = 0;      // Provisiosn Retrieval Results
  int retrieve_flag_c = 0;      // CLothing Retrieval Results

  int removal_flag_c = 0;       // Flag for removal Funcitons
  int removal_flag_h = 0;
  int removal_flag_p = 0;

  int removal_results_c = 0;     // Results from removal functions
  int removal_results_h = 0;
  int removal_results_p = 0;

  char temp[100];               // Temporary array for Function Use 
  int search_flag = 0;          // Flag Search history Use
  int housing_flag = 0;         // Flag for housing Menu
  int provisions_flag = 0;      // Flag for Provisions Menu
  int clothing_flag = 0;        // Flag for Clothing Menu

  int flag = 0;
  char temp_h[8] = "Housing";     // Used to Fill in Search History LLL
  char temp_p[11] = "Provisions"; // Same as above
  char temp_c[9] = "Clothing";    // Same as aboe


  list manager;                   // CLL List object
  search_list search_manager;     // LLL List object
  housing h_object;               // Housing Object
  clothing c_object;              // Clothing Object
  provisions p_object;            // Provisions Object

  search_manager.Add(1);          // Creates Housing Node in Search History LLL
  search_manager.Add(2);          // Creates Clothing Node in Search History LLL
  search_manager.Add(3);          // Creates Provisions Node in Search History LLL
 

  // Options to select whether to donate or select help 
  // THERE IS NO FUNCTIONAL DIFFERENCE BETWEEN THE TWO
  cout << "\nDo you wish to add/donate to the relief efforts or"
       << "\nDo you wish to select a relief effort for yourself?" 
       << "\n1. Make a donation"
       << "\n2. Select a relief effort for yourself"
       << endl;

  cin >> main_selection;
  cin.ignore(100,'\n');

  while(main_selection < 1 || main_selection > 2)
  {
    cout << "\nDo you wish to add/donate to the relief efforts or"
         << "\nDo you wish to select a relief effort for yourself?" 
         << "\n1. Make a donation"
         << "\n2. Select a relief effort for yourself"
         << endl;

    cin >> main_selection;
    cin.ignore(100,'\n');
  } 

  // Loop that will continue the program until user wishes to Quit
  while(effort_selection != 5)
  {

    // Make A donation
    if(main_selection == 1)
    {
      cout << "\n\nYou have chosen to make a donation!"
	   << "\nThere are three different categories that"
	   << "\nyou have to choose from."
	   << "\n\n1. Housing"
	   << "\n2. Provisions"
	   << "\n3. Clothing" 
	   << "\n4. Search History"
	   << "\n5. Quit"
           << endl;	
     
      cin >> effort_selection;
      cin.ignore(100,'\n');

      // Resets menu choices after each iteration
      search_selection = 0; 
      housing_selection = 0; 
      clothing_selection = 0;
      provisions_selection = 0;
 


      // Housing Choice
      // Increases frequency for Search History
      if(effort_selection == 1 && housing_flag == 0 && search_flag == 0)
      {
         search_manager.increase(temp_h);
         search_manager.Sort();
      }

      // Provisions Coice
      // Increases frequency for Search History
      if(effort_selection == 2 && provisions_flag == 0 && search_flag == 0)
      {
         search_manager.increase(temp_p);
         search_manager.Sort();
      }

      // Clothing Chocie
      // Increases frequency for Search History
      if(effort_selection == 3 && clothing_flag == 0 && search_flag == 0)
      {
         search_manager.increase(temp_c);
         search_manager.Sort();
      }

    }


    if(main_selection == 2)
    {
      // Chose to accept a relieg effort
      cout << "\n\nYou have chosen to accept a relief effort"
	   << "\nThere are three different categories that"
	   << "\nyou have to choose from."
	   << "\n\n1. Housing"
	   << "\n2. Provisions"
	   << "\n3. Clothing" 
	   << "\n4. Search History"
	   << "\n5. Main Menu"
           << endl;	
      cin >> effort_selection;
      cin.ignore(100,'\n');
   
      while(effort_selection < 1 || effort_selection > 5)
      { 
        cout << "\n\nYou have chosen to accept a relief effort"
             << "\nThere are three different categories that"
	     << "\nyou have to choose from."
	     << "\n\n1. Housing"
	     << "\n2. Provisions"
	     << "\n3. Clothing" 
	     << "\n4. Search History"
	     << "\n5. Main Menu"
             << endl;	
        cin >> effort_selection;
        cin.ignore(100,'\n');
      }


      // Resets Menu Choices each iteration 
      search_selection = 0; 
      housing_selection = 0; 
      clothing_selection = 0;
      provisions_selection = 0;
      
     
      // Housing Choice
      // Increases frequency for Search History
      if(effort_selection == 1 && housing_flag == 0 && search_flag == 0)
      {
         search_manager.increase(temp_h);
      }

      
      // Provisions Coice
      // Increases frequency for Search History
      if(effort_selection == 2 && provisions_flag == 0 && search_flag == 0)
      {
         search_manager.increase(temp_p);
      }


      // Clothing Coice
      // Increases frequency for Search History
      if(effort_selection == 3 && clothing_flag ==0 && search_flag == 0)
      {
         search_manager.increase(temp_c);
      }

    }


    // User has previously chose to turn off Search History
    if(effort_selection == 4 && search_flag == 1)
    {
      cout << "\n**Error**\n Search History has been turned off."
	   << "\nReturning to Main Menu" << endl;
    }

   
    // Search History Option 
    while(search_selection != 5 && effort_selection == 4 && search_flag == 0)
    {
      cout << "\n\nYou have chosen Search History"
	   << "\nThere are 3 different categories that"
	   << "\nyou can to choose from."
	   << "\n\n**Warning**\nIf you select Turn Off the"
	   << "\nSearch History, it will be permanently cleared and turned off."
	   << "\n\n1. Display Search History"
	   << "\n2. Clear Search History"
	   << "\n3. Retrieve Search"
	   << "\n4. Turn Off Search History" 
	   << "\n5. Return to Effort Type Menu" 
          << endl;	
      cin >> search_selection;
      cin.ignore(100,'\n');

      // Displays SH
      if(search_selection == 1)
	 search_manager.Wrapper_display();

      // Clears SH
      if(search_selection == 2)
	 search_manager.Reset_History();
     
      //Retriece One SH 
      if(search_selection == 3 && clothing_flag ==0)
      {
	 cout << "Please choose the name of the category."
	      << "\n1. Housing"
	      << "\n2. Provisions"
	      << "\n3. Clothing" 
	      << endl;

         cin >> search_retrieval;
         cin.ignore(100,'\n');

	  while(search_retrieval < 1 || search_retrieval > 3)
          {
	    cout << "Please choose the name of the category."
	         << "\n1. Housing"
	         << "\n2. Provisions"
	         << "\n3. Clothing" 
	         << endl;

                cin >> search_retrieval;
                cin.ignore(100,'\n');
          }


	 // Housing option
	 if(search_retrieval == 1)
         {
           retrieval_results = search_manager.Retrieve_search(temp_h);
           cout << temp_h << " had " << retrieval_results << " searches." << endl;
	 }

	 // Provisions Option
	 if(search_retrieval == 2)
	 {
           retrieval_results = search_manager.Retrieve_search(temp_p);
           cout << temp_p << " had " << retrieval_results << " searches." << endl;
         }

	 // Clothing Option
	 if(search_retrieval == 3)
         {
           retrieval_results = search_manager.Retrieve_search(temp_c);
           cout << temp_c << "had " << retrieval_results << " searches." << endl;
	 }
      } 
     
      // "Turns off" SH 
      if(search_selection == 4)
      {
        search_manager.Wrapper_Remove_All();
        search_flag = 1;
      }
    }


    // Housing CLL Option
    while(housing_selection != 6 && effort_selection == 1)
    {
      cout << "\n\nYou have chosen Housing"
	   << "\nThere are five different categories that"
	   << "\nyou have to choose from."
	   << "\n\n1. Add a Housing option"
	   << "\n2. Display all Housing Options" 
	   << "\n3. Remove a Housing option"
	   << "\n4. Search for one Housing Option" 
	   << "\n5. Retrieve a Housing Option" 
	   << "\n6. Return to Effort Type Menu" 
          << endl;	
      cin >> housing_selection;
      cin.ignore(100,'\n');

      // Add Node
      if(housing_selection == 1)
      { 
         manager.Add_housing(); 
         retrieve_flag_h = 1;
         
	 if(removal_flag_h == 1)
	   removal_flag_h = 0;
      }

      // Display CLL
      if(housing_selection == 2 && retrieve_flag_h == 1 && removal_flag_h == 0)
        manager.Wrapper_display(1);
     

      else if(housing_selection == 2 && retrieve_flag_h == 0)
	 cout << "No items have been added yet" << endl;


      // Remove Match
      if(housing_selection == 3 && retrieve_flag_h == 1 && removal_flag_h == 0)
      {
        cout << "\nPlease enter the street name of the housing you wish to remove" << endl;
	cin.get(temp,100,'\n');
	cin.ignore(100,'\n');
        removal_results_h = manager.Wrapper_remove(1,temp);    
	

	if(removal_results_h == 3)
        {
	  removal_flag_h = 1;
	  cout << "All items have been removed" << endl;
	}

       } 

      else if(housing_selection == 3 && retrieve_flag_h == 0)
	 cout << "No items have been added yet" << endl;


      // Display One Type
      if(housing_selection == 4 && retrieve_flag_h && removal_flag_h == 0)
      {
        cout << "\nPlease enter the street name of the housing you wish to display" << endl;
	cin.get(temp,100,'\n');
	cin.ignore(100,'\n');
        manager.Wrapper_display_type(2,temp);
      }
      
      else if(housing_selection == 4  && retrieve_flag_h == 0 || removal_flag_h != 0)
	 cout << "No items have been added yet" << endl;


      // Retrieve Match
      if(housing_selection == 5 && retrieve_flag_h == 1 && removal_flag_h == 0)
      {
        cll_result = manager.Wrapper_Retrieve(h_object,c_object,p_object,1);

	if(cll_result == 1)
          h_object.display(1);

	else
           cout << "That name was not found" << endl;
      }
     
      
      // Empty List, Can't Retriece Yet 
      else if(housing_selection == 5  && retrieve_flag_h != 1)
	 cout << "No items have been added yet" << endl;

    }


    // Provsisions Option CLL    
    while(provisions_selection != 6 && effort_selection == 2)
    {
      cout << "\n\nYou have chosen Provisions"
	   << "\nThere are five different categories that"
	   << "\nyou have to choose from."
	   << "\n\n1. Add a Provisions option"
	   << "\n2. Display all Provisions Options" 
	   << "\n3. Remove a Provisions option"
	   << "\n4. Search for one Provisions Option" 
	   << "\n5. Retrieve a Provisions Option" 
	   << "\n6. Return to Effort Type Menu" 
          << endl;	
      cin >> provisions_selection;
      cin.ignore(100,'\n');


      // Add node
      if(provisions_selection == 1)
      {
         manager.Add_provisions(); 
         retrieve_flag_p = 1;
         
	 if(removal_flag_p == 1)
	   removal_flag_p = 0;
      }

      //Display CLL
      if(provisions_selection == 2 && retrieve_flag_p == 1 && removal_flag_p == 0)
        manager.Wrapper_display(2);

      else if(provisions_selection == 2 && retrieve_flag_p == 0)
	 cout << "No items have been added yet" << endl;

      // Remove match
      if(provisions_selection == 3 && removal_flag_p == 0)
      {
        cout << "\nPlease enter the food name of the provision you wish to remove" << endl;
	cin.get(temp,100,'\n');
	cin.ignore(100,'\n');
        removal_results_p =  manager.Wrapper_remove(2,temp);    
       
	
	if(removal_results_p == 3)
	{
	  removal_flag_p = 1;
	  cout << "All items have been removed" << endl;
	}
      }

      else if(provisions_selection == 3 && retrieve_flag_p == 0)
	 cout << "No items have been added yet" << endl;

      
      // Display One Type
      if(provisions_selection == 4 && retrieve_flag_p == 1 && removal_flag_p == 0)
      {
        cout << "\nPlease enter the provision name of the provisions you wish to display" << endl;
	cin.get(temp,100,'\n');
	cin.ignore(100,'\n');
        manager.Wrapper_display_type(1,temp);

      }

      else if(provisions_selection == 3  && retrieve_flag_p == 1 && removal_flag_p == 1)
	 cout << "All items have been removed" << endl;


      else if(provisions_selection == 4 && retrieve_flag_p == 0)
	 cout << "No items have been added yet" << endl;

     
      // Retrieve Match
      if(provisions_selection == 5 && retrieve_flag_p == 1 && removal_flag_p == 0)
      {
	      
	cll_result = manager.Wrapper_Retrieve(h_object,c_object,p_object,2);
	
	if(cll_result == 1)
          p_object.display(1);

	else
           cout << "That name was not found" << endl;
      }
      
      // Empty List 
      else if(provisions_selection == 5  && retrieve_flag_p != 1)
	 cout << "No items have been added yet" << endl;
    }
  

    
    // Clothing option CLL 
    while(clothing_selection != 6 && effort_selection == 3)
    {

      cout << "\n\nYou have chosen Clothing"
	   << "\nThere are five different categories that"
	   << "\nyou have to choose from."
	   << "\n\n1. Add a Clothing option"
	   << "\n2. Display all Clothing Options" 
	   << "\n3. Remove a Clothing option"
	   << "\n4. Search for one Clothing Option" 
	   << "\n5. Retrieve a Clothing Option" 
	   << "\n6. Return to Effort Type Menu" 
          << endl;	
      cin >> clothing_selection;
      cin.ignore(100,'\n');


      // Add Node
      if(clothing_selection == 1)
      {
         manager.Add_clothing(); 
         retrieve_flag_c = 1;

         if(removal_flag_c == 1)
	   removal_flag_c = 0;
      }

      // Display All
      if(clothing_selection == 2 && retrieve_flag_c == 1 && removal_flag_c == 0)
        manager.Wrapper_display(3);

      else if(clothing_selection == 3  && retrieve_flag_c == 0)
	 cout << "No items have been added yet" << endl;

      // Remove Match
      if(clothing_selection == 3 && retrieve_flag_c == 1 && removal_flag_c == 0)
      {
        cout << "\nPlease enter the clothing name of the clothing you wish to remove" << endl;
	cin.get(temp,100,'\n');
	cin.ignore(100,'\n');
        removal_results_c = manager.Wrapper_remove(3,temp);    
   
	if(removal_results_c == 3)
        {
	  removal_flag_c = 1;
	  cout << "All items have been removed" << endl;
	}
      }
     
      else if(clothing_selection == 3  && retrieve_flag_c == 1 && removal_flag_c == 1)
	 cout << "All items have been removed" << endl;

      else if(clothing_selection == 3  && retrieve_flag_c == 0)
	 cout << "No items have been added yet" << endl;


      // Display One Type 
      if(clothing_selection == 4 && retrieve_flag_c == 1 && removal_flag_c == 0)
      {
        cout << "\nPlease enter the clothing name of the clothing you wish to display" << endl;
	cin.get(temp,100,'\n');
	cin.ignore(100,'\n');
        manager.Wrapper_display_type(3,temp);
      }

      else if(clothing_selection == 4  && retrieve_flag_c == 0)
	 cout << "No items have been added yet" << endl;

     
      // Retrieve Match
      if(clothing_selection == 5  && retrieve_flag_c == 1 && removal_flag_c == 0)
      {
        cll_result = manager.Wrapper_Retrieve(h_object,c_object,p_object,3);

        if(cll_result == 1) 
	  c_object.display(1);

	else
          cout << "That name was not found" << endl;
      }
      
     // Empty List 
      else if(clothing_selection == 5  && retrieve_flag_c != 1)
	 cout << "No items have been added yet" << endl;
    }
  } 


  return;

}

