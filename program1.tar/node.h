#include"program1.h"
// Channer Bok .h file for nodes for the CLL and LLL
// As well as their respective list manager classes



// Provisions Node for the CLL
// DERIVED FROM PROVISIONS CLASS
class provisions_node: public provisions
{
      public:
	    provisions_node();                       // Constructor
	    ~provisions_node();                      // Deconstructor
	    provisions_node *& get_next();           // Get Next
            void set_next(provisions_node * & temp); // Set Next
      protected:
            provisions_node * next;  // Next Pointer
};


// Clothing Node for the CLL
// DERIVED FROM CLOTHING CLASS
class clothing_node: public clothing
{
      public:
	    clothing_node();                      // Constructor
	    ~clothing_node();                     // Deconstructor
	    clothing_node *& get_next();          // Get Next
            void set_next(clothing_node * & temp);// Set Next
      protected:
            clothing_node * next;  // Next Pointer
};



// Housing Node for the CLL
// DERIVED FROM HOUSING CLASS
class housing_node: public housing
{
      public:
	    housing_node();                       //Constructor
 	    ~housing_node();                      // Deconstructor
	    housing_node *& get_next();           // Get Next
            void set_next(housing_node * & temp); // Set Next
      protected:
            housing_node * next;  // Next Pointer
};


class list
{
      public:
	    list();
	    ~list();

	    // Wrappers for all three of the CLL's
            int Wrapper_display(int selection);                   // Wrapper for Display Functions
	    int Wrapper_remove(int selection,char name[]);        // Wrapper for Remove
	    int Wrapper_display_type(int selection,char name[]);  // Wrapper for Display One Type
            int Wrapper_Retrieve(housing & h_object, clothing & c_object, provisions & p_object, int selection); // Wrapper for Retrieve


	    // Clothing Functions
	    int Add_clothing();                                                                                         // Add Clothing Node
            int deletion_clothing(clothing_node * & current,clothing_node * rear);                                      // Deallocates CLL
            int Remove_clothing(clothing_node * & front,char name[], clothing_node *& rear, clothing_node * & previous);// Removes the matching Node
	    int Display_All_clothing(clothing_node * front, clothing_node * rear);                                      // Displays all Nodes
            int Display_Type_clothing(clothing_node * current, clothing_node * rear,char street[]);                     // Displays One Type
            int Retrieve_clothing(clothing_node * current, clothing_node * rear, char name[], clothing & object);       // Retrieves match
        

	    // Housing Functions
	    int Add_housing();                                                                                          // Add Housing Node
            int deletion_housing(housing_node * & current,housing_node * rear);                                         // Deallocates CLL
            int Remove_housing(housing_node * & front,char name[], housing_node *& rear, housing_node * & previous);    // Removes Match
	    int Display_All(housing_node * front, housing_node * rear);                                                 // Displasy all nodes
            int Display_Type(housing_node * current, housing_node * rear,char street[]);                                // Displays One Type
            int Retrieve(housing_node * current, housing_node * rear, char street_name[], housing & object);            // Retrieves Match


	    // Provisions Functions
	    int Add_provisions();                                                                                               // Add Provisions Node
            int deletion_provisions(provisions_node * & current,provisions_node * rear);                                        // Deallocates CLL
            int Remove_provisions(provisions_node * & front,char name[], provisions_node *& rear, provisions_node * & previous);// Removes Match
	    int Display_All_provisions(provisions_node * front, provisions_node * rear);                                        // Displays all nodes
            int Display_Type_provisions(provisions_node * current, provisions_node * rear,char street[]);                       // Displays One Type
            int Retrieve_provisions(provisions_node * current, provisions_node * rear, char name[], provisions & object);       // Retrieve Match


      protected:

	   housing_node * housing_rear;      // Housing CLL Rear
           clothing_node * clothing_rear;    // Clothing CLL Rear
           provisions_node * provisions_rear;// Provisions CLL Rear

};



// Search History Node Class
class search_node
{
     public: 
	     search_node();                                              // Constructor
	     ~search_node();                                             // Deconstructor
	     search_node *& get_next();                                  // Get Next
             void set_next(search_node * & temp);                        // Set Next 
	     void read(int selection);                                   // Reads in Data


	     int increase_frequency(char temp[], search_node * & head);  // Increases Node Frequency
	     int check(char temp[]);                                     // Checks for a match
	     int check_freq();                                           // Checks Node Frequency
	     int search_sort(search_node * & head);                      // Sorts LLL by Frequency

             int deletion_search(search_node * & head);                  // Deallocates LLL 
	     int display(search_node * head);                            // Display LLL 
	     int Remove_All(search_node * & head);                       // Removes All Nodes
             int reset(search_node * & head);                            // Sets all Nodes Frequencies to 0
	     int retrieve(search_node * head, char copy_name[]);         // Retrieves Match

     protected:
	     int frequency;      // Number of Searches
	     char * name;        // Name of type of search
	     search_node * next; // Next Pointer for LLL
             
};



class search_list
{
     public:
            //search_list();
	    search_list();
	    ~search_list(); 
	    void Add(int selection);    // Add Node
            int Sort();                 // Wrapper for sorting by freq
	    int increase(char temp[]);  // Wrapper for Increase Function
	    int Reset_History();        // Wrapper for reset freq to 0
            int Wrapper_deletion_search();                  // Deallocates LLL 
            
	    // Wrapper Functions 
	    int Wrapper_display();      // Wrapper for Display
            int Wrapper_Remove_All();   // Wrapper for remove all
            int Retrieve_search(char copy_name[]); // Wrapper for Retrieve

     protected:
	     search_node * head; // Head of LLL

};

// Function Prototype for main menu Function in main.cpp
void main_menu();























