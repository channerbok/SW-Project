#include"node.h"
// Channer Bok
// Provisons now implementation & List Class Wrapper Functions implmentation


// Constructor
provisions_node::provisions_node()
{
  next = NULL;
}


// Deconstructor
// All memory is delete using the List Class deconstructor
// and the deletion Function Below
provisions_node::~provisions_node()
{

}



// Deletes CLL
int list::deletion_provisions(provisions_node * & current,provisions_node * rear)
{

  if(current == rear)
  {
    delete current;
    return 1;
  }
 
  provisions_node * hold = current -> get_next(); 
  
  delete current; 
  current = hold;
  deletion_provisions(current,rear);

  return 0;
}



// Get next Function
provisions_node *& provisions_node::get_next()
{
  return next;
}


// Set Next
void provisions_node::set_next(provisions_node * & temp)
{
  this -> next = temp;
}


// Add node to CLL
int list::Add_provisions()
{
  provisions_node * hold;  
  provisions_node * temp;
 
  if(provisions_rear == NULL)
  { 
    provisions_rear = new provisions_node;
    provisions_rear -> provisions::creation(1);
    provisions_rear -> provisions::alter();
    provisions_rear -> read();
    provisions_rear -> set_next(provisions_rear);  
    return 1;
  }
  
  else
  {
    hold = provisions_rear -> get_next();
    temp = new provisions_node;
    temp -> provisions::creation(1);
    temp -> read();
    temp -> set_next(hold);  
    provisions_rear -> set_next(temp);
  }

  return 0;
}



// Remove match from CLL
int list::Remove_provisions(provisions_node * & front,char name[], provisions_node *& rear, provisions_node * & previous)
{
  int result = 0;


  provisions_node * temp;
  provisions_node * hold;
  result = front -> comparison(name);  

  if(result == 1)
  {
    hold = front -> get_next();
    temp = rear -> get_next();

    if(hold == temp)
    {
      hold = rear -> get_next();
      previous -> set_next(hold);
      rear = previous;
      rear -> set_next(hold); 
      front -> provisions::creation(0);
      //delete front;
      return 1;
    }

    temp = front -> get_next();
    previous -> set_next(temp); 
    front -> provisions::creation(0);
    //delete front; 
    return 1;
  }

  if(front == rear)
  {
    return 1;
  }
  
  
  front = front -> get_next();
  previous = previous -> get_next();
  Remove_provisions(front,name,rear,previous);

  return 0;
}



// Display all Nodes
int list::Display_All_provisions(provisions_node * front, provisions_node * rear)
{
  if(front == rear)
  {
    front -> display();
    return 1;
  }

  front -> display();
  front = front -> get_next();
  Display_All_provisions(front,rear);

  return 0;
}




// Display match
int list::Display_Type_provisions(provisions_node * current, provisions_node * rear,char street[])
{
  int results = 0;
  
  
  if(current == rear)
  {
    results = current -> comparison(street);
    if(results == 1)
    {
      current -> display();
    }
    return 1;
  }

  results = current -> comparison(street);

  if(results == 1)
  {
    current -> display();
    return 1;
  }

  current = current -> get_next();
  Display_Type_provisions(current,rear,street);
  return 0;
}



// Retrieve Match and send back
int list::Retrieve_provisions(provisions_node * current, provisions_node * rear, char name[], provisions & object)
{ 
  int results = 0;
 
 
  if(current == rear)
  {
    results = current -> comparison(name);
    
    if(results == 1)
    {
      current -> read(object);
      return 1;
    }

    return 0;
  }

  results = current -> comparison(name);

  if(results == 1)
  {
    current -> read(object);
    return 1;
  }

  current = current -> get_next();
  Retrieve_provisions(current,rear,name,object);
  return 0;
}


 
 




// LIST CLASSS IMPLEMENTATION



// Constructor
list::list()
{

  housing_rear = NULL; 
  provisions_rear = NULL;
  clothing_rear = NULL;
}


// Deconstructor
list::~list()
{
  if(housing_rear != NULL)
  {
    housing_node * current_h = housing_rear -> get_next();
    housing_node * rear_h = housing_rear;
    
    if(current_h != NULL)
    {
      deletion_housing(current_h,rear_h);
    }

    else
    {
      delete current_h;
    } 

  }

  if(clothing_rear != NULL)
  {
    clothing_node * current_c = clothing_rear -> get_next();
    clothing_node * rear_c = clothing_rear;
    
    if(current_c != NULL)
    {
      deletion_clothing(current_c,rear_c);
    }

    else
    {
      delete current_c;
    } 

  }

  if(provisions_rear != NULL)
  {
    provisions_node * current_p = provisions_rear -> get_next();
    provisions_node * rear_p = provisions_rear;
    
    if(current_p != NULL)
    {
      deletion_provisions(current_p,rear_p);
    }

    else
    {
      delete current_p;
    } 

  }
}






// Wrappers for all list functions
int list::Wrapper_remove(int selection,char name[])
{

  int result; 

  if(selection == 1)
  {
    result = housing_rear -> comparison(name);  
   
    if(housing_rear == housing_rear->get_next() && result == 1)
    { 
      delete housing_rear;
      housing_rear == NULL;
      return 3;
    }


    housing_node * current = housing_rear->get_next();
    housing_node * previous = housing_rear -> get_next();
    housing_node * rear = housing_rear;
    current = current -> get_next(); 
  
    // If the first node is the match
    result = previous -> comparison(name);  
    
    if(result == 1)
    {
      rear -> set_next(current); 
      previous -> housing::creation(0);
      //delete previous; 
      return 1;
    }
 

    // Function call for recursive function. 
    Remove_housing(current,name,rear,previous);
    housing_rear = rear;

    return 1;
  }

  if(selection == 2)
  { 
    result = housing_rear -> comparison(name);  
   
    if(provisions_rear == provisions_rear->get_next() && result == 1)
    {
      provisions_rear = NULL;
      delete provisions_rear;
      return 3;
    }


    provisions_node * current = provisions_rear->get_next();
    provisions_node * previous = provisions_rear -> get_next();
    provisions_node * rear = provisions_rear;
    current = current -> get_next(); 

    // If the first node is the match
    result = previous -> comparison(name);  
  
    if(result == 1)
    {
      rear -> set_next(current); 
      previous -> provisions::creation(0);
      //delete previous; 
      return 1;
    }
  
    // Function call for recursive function. 
    Remove_provisions(current,name,rear,previous);
    provisions_rear = rear;
    return 0;
  }
  
  if(selection == 3)
  {
    result = housing_rear -> comparison(name);  

    if(clothing_rear == clothing_rear->get_next() && result == 1)
    {
      delete clothing_rear;
      clothing_rear = NULL;
      return 3;
    }

    clothing_node * current = clothing_rear->get_next();
    clothing_node * previous = clothing_rear -> get_next();
    clothing_node * rear = clothing_rear;
    current = current -> get_next(); 
  
    // If the first node is the match
    result = previous -> comparison(name);  
    if(result == 1)
    {
      rear -> set_next(current); 
      previous -> clothing::creation(0);
      //delete previous; 
      return 1;
    }
  
    // Function call for recursive function. 
    Remove_clothing(current,name,rear,previous);
    clothing_rear = rear;
    return 1;
  }

  return 1;
}


// To display all nodes in the CLL
int list::Wrapper_display(int selection)
{
  if(selection == 1)
  {
    housing_node * current = housing_rear->get_next();
    housing_node * rear = housing_rear;
    Display_All(current,rear);
    return 1;
  }

  if(selection == 2)
  { 
    provisions_node * current = provisions_rear->get_next();
    provisions_node * rear = provisions_rear;
    Display_All_provisions(current,rear);
    return 1;
  }

  if(selection == 3)
  {
    clothing_node * current = clothing_rear->get_next();
    clothing_node * rear = clothing_rear;
    Display_All_clothing(current,rear);
    return 1;
  }

  return 1;
}


// To display a Node with the matching name
int list::Wrapper_display_type(int selection, char name[])
{
  if(selection == 2)	
  {
    housing_node * rear = housing_rear;
    housing_node * current = housing_rear -> get_next();
    Display_Type(current,rear,name);  
    return 1;
  }

  if(selection == 3)
  {
    clothing_node * rear = clothing_rear;
    clothing_node * current = clothing_rear -> get_next();
    Display_Type_clothing(current,rear,name);  
    return 1;
  }

  if(selection == 1)
  {
    provisions_node * rear = provisions_rear;
    provisions_node * current = provisions_rear -> get_next();
    Display_Type_provisions(current,rear,name);  
    return 1;
  }

  return 1;
}



// Calls the desired classes retrieval function
int list::Wrapper_Retrieve(housing & h_object,clothing & c_object, provisions & p_object,int selection)
{
  char name[20];
  
  
  if(selection == 1)
  {
    cout << "Please enter the name of the housing street you wish to retrieve" << endl;
    cin.get(name,20,'\n');
    cin.ignore(100,'\n');
    housing_node * rear = housing_rear;
    housing_node * current = housing_rear -> get_next();
    int result = Retrieve(current,rear,name,h_object);
    return result;
  }


  if(selection == 2)
  {
    cout << "Please enter the name of the provision you wish to retrieve" << endl;
    cin.get(name,20,'\n');
    cin.ignore(100,'\n');

    provisions_node * rear = provisions_rear;
    provisions_node * current = provisions_rear -> get_next();
    int result = Retrieve_provisions(current,rear,name,p_object);
    return result;
  }
  
  if(selection == 3)
  {
    cout << "Please enter the name of the clothing you wish to retrieve" << endl;
    cin.get(name,20,'\n');
    cin.ignore(100,'\n');
    clothing_node * rear = clothing_rear;
    clothing_node * current = clothing_rear -> get_next();
    int result = Retrieve_clothing(current,rear,name,c_object);
    return result;
  }

  return 1;
}


