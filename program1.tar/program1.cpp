// Channeer Bok Relief Effort FUnciton Implemenation



#include"node.h"


// BASE CLASS FUNCTION IMPLEMENTATION -- RELIEF


// Constructor
relief::relief()
{
  age = 0;
  number_of_dependants = 0;
  full_name = NULL;
  address = NULL;
  zip = NULL;

}

//Deconstructor
relief::~relief()
{
  delete [] full_name;
  delete [] address;
  delete [] zip;

}


// Copy Constructor
relief::relief(const relief & to_copy)
{
  age = to_copy.age;

  full_name = new char[strlen(to_copy.full_name)+1];
  strcpy(full_name,to_copy.full_name);

}



// Display Relief Info
void relief::display()
{
  cout << endl << endl 
       << "The name assigned to this is " << full_name << endl
       << "\nTheir address is " << address << endl
       << "\nTheir age is " << age << endl
       << "\nAnd their number of dependants is " << number_of_dependants << endl;
}


// Reads in Relief infor from User
void relief::creation()
{
  char temp[40];

  cout << "\nPlease enter your information below:"
       << "\nYour full name: " << endl;

  cin.get(temp,40,'\n');
  cin.ignore(100,'\n');

  full_name = new char[strlen(temp) + 1];
  strcpy(full_name,temp);

  cout << "\nYour full Addreess " << endl;
  cin.get(temp,40,'\n');
  cin.ignore(100,'\n');

  address = new char[strlen(temp) + 1];
  strcpy(address,temp);

  cout << "\nYour full Address except the zipcode " << endl;
  cin.get(temp,40,'\n');
  cin.ignore(100,'\n');

  zip = new char[strlen(temp) + 1];
  strcpy(zip,temp);
  
  cout << "\nYour full age " << endl;
  cin >> age;
  cin.ignore(100,'\n'); 


  cout << "\nYour number of dependants" << endl;
  cin >> number_of_dependants;
  cin.ignore(100,'\n'); 
  
}


int relief::alter()
{
  int selection = 0;
  cout << "\nWould you like to change your information?" 
       << "\n1.Change name"
       << "\n2.Change address"
       << "\n3.Change Zip"
       << "\n4.None"
       << endl;
  cin >> selection;
  cin.ignore(100,'\n');

  if(selection == 1) 
   change_name();

  if(selection == 2)
   change_address();

  if(selection == 3) 
   change_dependants();

  return 0;
}




// Alter relief data
int relief::change_name()
{
  char temp[30];
  delete full_name;

  cout << "Please enter the name you wish to have" << endl;
  cin.get(temp,40,'\n');
  cin.ignore(100,'\n');

  full_name = new char[strlen(temp) + 1];
  strcpy(full_name,temp);
  
  return 0;

}



// Alter relief data
int relief::change_address()
{

  char temp[30];
  delete address;

  cout << "Please enter the name you wish to have" << endl;
  cin.get(temp,40,'\n');
  cin.ignore(100,'\n');

  address = new char[strlen(temp) + 1];
  strcpy(address,temp);
  return 0;
}



// Alter relief data
int relief::change_dependants()
{
  cout << "\nYour number of dependants" << endl;
  cin >> number_of_dependants;
  cin.ignore(100,'\n'); 
  return 0;

}





// DERIVED CLASS FUNCITON IMPLEMENTATION -- HOUSING
//



// Constructor
housing::housing()
{
  address = NULL;
  rooms = 0;
}



// Deconstructor
housing::~housing()
{
  delete [] street;
  delete [] city;
  delete [] zip; 
}




// Display Object info
// Calls base class Display
void housing::display()
{
  relief::display();
  cout << "\nHousing Information" << endl;
  cout << "The street is  " << street << endl
       << "The city is " << city << endl
       << " The zip is " << zip << endl
       << "and the amount of rooms are " << rooms 
       << endl;
}




// Display Obejct info
// Does NOT call base class Displau
void housing::display(int num)
{

  cout << "\nHousing Information" << endl;
  cout << "The street is  " << street << endl
       << "The city is " << city << endl
       << "The zip is " << zip << endl
       << "and the amount of rooms are " << rooms 
       << endl;
}




// Calls Base Class Creation Function
// Also deletes
void housing::creation(int flag)
{
  if(flag == 1)
  {
    relief::creation();  
    return;
  }

  else
  {
    delete [] street;
    delete [] city;
    delete [] zip;
  }

}



// Calls Base Class Alter Function
void housing::alter()
{
  relief::alter();  
}



// Compares Passed array to housing information
// Return Result
int housing::comparison(char temp[])
{
  if(strcmp(street,temp) == 0)
     return 1;

  return 0;
}




// Housing Copy Constructor
housing::housing(const housing & to_copy)
{
  street = new char[strlen(to_copy.street) + 1];
  strcpy(street,to_copy.street);

  zip = new char[strlen(to_copy.zip) + 1];
  strcpy(zip,to_copy.zip); 
  
  city = new char[strlen(to_copy.city) + 1];
  strcpy(city,to_copy.city);

  rooms = to_copy.rooms;
}




// Obtains housing information from user
void housing::read()
{
  char temp[40];
  
  cout << "Please enter the street" << endl;
  cin.get(temp,40,'\n');
  cin.ignore(100,'\n'); 
  street = new char[strlen(temp) + 1];
  strcpy(street,temp);


  cout << "Please enter the zip code" << endl;
  cin.get(temp,40,'\n');
  cin.ignore(100,'\n'); 
  zip = new char[strlen(temp) + 1];
  strcpy(zip,temp); 

  cout << "Please enter the city" << endl;
  cin.get(temp,40,'\n');
  cin.ignore(100,'\n'); 
  city = new char[strlen(temp) + 1];
  strcpy(city,temp);

  cout << "Please enter the rooms" << endl;
  cin >> rooms;
  cin.ignore(100,'\n'); 
}




// Copies data into object for retrieval
void housing::read(housing & object)
{
  object.street = new char[strlen(street) + 1];
  strcpy(object.street,street);

  object.zip = new char[strlen(zip) + 1];
  strcpy(object.zip,zip); 
  
  object.city = new char[strlen(city) + 1];
  strcpy(object.city,city);

  object.rooms = rooms;
}





// DERIVED CLASS FUNCITON IMPLEMENTATION -- Provisions


// Constructor
provisions::provisions()
{
  expiration_date = 0;
  food_name = NULL;
}




// Copy Constructor
provisions::provisions(const provisions & to_copy)
{
  expiration_date = to_copy.expiration_date;
  food_name = new char[strlen(to_copy.food_name)+1];
  strcpy(food_name,to_copy.food_name);
}



// Deconstructor
provisions::~provisions()
{
  delete [] food_name;
}



// Conpares passed array to objects food name 
int provisions::comparison(char temp[])
{

  if(strcmp(food_name,temp) == 0)
    return 1;

  else return 0;
}




// Reads in objects information from the user
void provisions::read()
{
  char temp[40];

  cout << "Please enter the food name" << endl;
  cin.get(temp,40,'\n');
  cin.ignore(100,'\n'); 
  food_name = new char[strlen(temp) + 1];
  strcpy(food_name,temp);

  cout << "Please enter the expiration date" << endl;
  cin >> expiration_date;
  cin.ignore(100,'\n'); 
}


// Copies info into a passed object
void provisions::read(provisions & object)
{
  object.food_name = new char[strlen(food_name) + 1];
  strcpy(object.food_name,food_name);

  object.expiration_date = expiration_date;
}


// Displays object Info
// Calls Base Class Display
void provisions::display()
{
  relief::display();
  cout << "\nProvisions Information" << endl;
  cout << "The food name is " << food_name << endl
       << "The expiration date is " << expiration_date << endl; 
}


// Displays Object Info
// Does not call Base Class Display
void provisions::display(int num)
{
  cout << "\nProvisions Information" << endl;
  cout << "The food name is " << food_name << endl
       << "The expiration date is " << expiration_date << endl; 
}


// Calls Base Classs Alter Function
void provisions::alter()
{
  relief::alter();  
}


// Calls Base Class creation function
void provisions::creation(int flag)
{

  if(flag == 1)
  {
    cout << "Thank you for selecting provisions."<< endl;
    relief::creation();  
  }
 
  else
    delete [] food_name;
}



// DERIVED CLASS FUNCITON IMPLEMENTATION -- Clothing



// Constructor
clothing::clothing()
{
  clothing_name = weather_category = NULL;
  size = 0;
}


// Copy Constuctor
clothing::clothing(const clothing & to_copy)
{
  size = to_copy.size;

  clothing_name = new char[strlen(to_copy.clothing_name) + 1];
  strcpy(clothing_name,to_copy.clothing_name);

  weather_category = new char[strlen(to_copy.weather_category) + 1];
  strcpy(weather_category,to_copy.weather_category);
}


// Deconstructor
clothing::~clothing()
{
  delete [] weather_category;
  delete [] clothing_name;
}


// Compares Passed array with objects clothing name
int clothing::comparison(char temp[])
{
  if(strcmp(clothing_name,temp) == 0)
     return 1;

  return 0;
}


//Copies info into object
void clothing::read(clothing & object)
{
  object.clothing_name = new char[strlen(clothing_name) + 1];
  strcpy(object.clothing_name,clothing_name);

  object.weather_category = new char[strlen(weather_category) + 1];
  strcpy(object.weather_category,weather_category); 

  object.size = size;
}



// Reads in object information from user
void clothing::read()
{
  char temp[40];

  cout << "Please enter the clothing name" << endl;
  cin.get(temp,40,'\n');
  cin.ignore(100,'\n'); 
  clothing_name = new char[strlen(temp) + 1];
  strcpy(clothing_name,temp);


  cout << "Please enter the weather category" << endl;
  cin.get(temp,40,'\n');
  cin.ignore(100,'\n'); 
  weather_category = new char[strlen(temp) + 1];
  strcpy(weather_category,temp); 


  cout << "Please enter the rooms" << endl;
  cin >> size;
  cin.ignore(100,'\n'); 

}

// Displays the objects information
// Calls base class display
void clothing::display()
{

  relief::display();
  cout << "\nClothing Information" << endl;
  cout << "The clothing name is " << clothing_name << endl
       << "The weather category is " << weather_category << endl
       << "and the size is " << size
       << endl;
}


// Displays the objects information
// Does NOT Call base class display
void clothing::display(int num)
{

  cout << "\nClothing Information" << endl;
  cout << "The clothing name is " << clothing_name << endl
       << "The weather category is " << weather_category << endl
       << "and the size is " << size
       << endl;

}



// Calls Base Classs Alter Function
void clothing::alter()
{
  relief::alter();  
}



// Calls Base CLass Creation Function
void clothing::creation(int flag)
{

  if(flag == 1)
  {
    cout << "Thank you for selecting Clothing."<< endl;
    relief::creation();  
    return;
  }

  else
  {
    delete [] clothing_name;
    delete [] weather_category;
  }
}

