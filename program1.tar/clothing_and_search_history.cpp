#include"node.h"
// Clothing node implementation & Search node/list implementation


// Constructor
clothing_node::clothing_node()
{
  next = NULL;
}

//Deconstructor
//All memory is delete using the List Class deconstructor
//and the deletion Function Below
clothing_node::~clothing_node()
{

}


// Deletes CLL
int list::deletion_clothing(clothing_node * & current,clothing_node * rear)
{

  if(current == rear)
  {
    delete current;
    return 1;
  }
 
  clothing_node * hold = current -> get_next(); 
  delete current; 
  current = hold;
  deletion_clothing(current,rear);


  return 0;
}



// Get Next Function for CLL
clothing_node *& clothing_node::get_next()
{
  return next;
}



// Set Next Function for CLL
void clothing_node::set_next(clothing_node * & temp)
{
  this -> next = temp;
}




// Adds a node to the front CLL
int list::Add_clothing()
{
  clothing_node * hold;  
  clothing_node * temp;

  // Empty CLL 
  if(clothing_rear == NULL)
  { 
    clothing_rear = new clothing_node;
    clothing_rear-> clothing::creation(1);
    clothing_rear-> clothing::alter();
    clothing_rear -> read();
    clothing_rear -> set_next(clothing_rear);  
    return 1;
  }
 
  // Non Empty 
  else
  {
    hold = clothing_rear -> get_next();
    temp = new clothing_node;
    temp->clothing::creation(1);
    temp -> read();
    temp -> set_next(hold);  
    clothing_rear -> set_next(temp);
  }

  return 0;
}




// Removes the node that matches the passed in array
int list::Remove_clothing(clothing_node * & front,char name[], clothing_node *& rear, clothing_node * & previous)
{
  // Local Variables 
  int result = 0;       // Holds function results
  clothing_node * temp; // For new node creation
  clothing_node * hold; // Holds next pointers
 
  // Compares Nodes name to passed name 
  result = front -> comparison(name);  

  // If theres a match
  if(result == 1)
  {
    hold = front -> get_next();
    temp = rear -> get_next();

    if(hold == temp)
    {
      hold = rear -> get_next();
      previous -> set_next(hold);
      rear = previous;
      rear -> set_next(hold); 
      
      front -> clothing::creation(0);
   //   delete front;
      return 1;
    }

    temp = front -> get_next();
    previous -> set_next(temp); 
    front -> clothing::creation(0);
  //  delete front; 
    return 1;
  }

  // At the end of the CLL 
  if(front == rear)
  {
    return 1;
  }
 
   
  front = front -> get_next();
  previous = previous -> get_next();
  Remove_clothing(front,name,rear,previous);

  return 0;
}


// Displays all the nodes in the CLL
int list::Display_All_clothing(clothing_node * front, clothing_node * rear)
{
  // At the at end of CLL
  if(front == rear)
  {
    front -> display();
    return 1;
  }

  front -> display();
  front = front -> get_next();
  Display_All_clothing(front,rear);

  return 0;
}


// Displays the node that matches the passed in array
int list::Display_Type_clothing(clothing_node * current, clothing_node * rear,char street[])
{
  int results = 0;
  
  // Match at end of CLL 
  if(current == rear)
  {
    // Compares passed array to current node
    results = current -> comparison(street);
    if(results == 1)
    {
      current -> display();
    }
    return 1;
  }

  // Compares passed array to current node
  results = current -> comparison(street);

  // Normal Match
  if(results == 1)
  {
    current -> display();
    return 1;
  }

  current = current -> get_next();
  Display_Type_clothing(current,rear,street);
  return 0;
}


// Finds the node that matches the passed array, copies data into it the passed object and returns it
int list::Retrieve_clothing(clothing_node * current, clothing_node * rear, char name[], clothing & object)
{
  
  int results = 0;

  // Match at end of CLL
  if(current == rear)
  {
    results = current -> comparison(name);
    
    if(results == 1)
    {
      current -> read(object);
      return 1;
    }
   
    return 0;
  }

  results = current -> comparison(name);

  // Normal Match
  if(results == 1)
  {
    current -> read(object);
    return 1;
  }

  current = current -> get_next();
  Retrieve_clothing(current,rear,name,object);
  
  return 0;
}





// SEARCH NODE IMPLEMENTATION
//
//
//



// Constructor
search_node::search_node()
{
  frequency = 0;
  name = NULL;

}

// Deconstructor
search_node::~search_node()
{


}


// Deallocates the Search History LLL
int search_node::deletion_search(search_node * & head)
{
  
  if(head == NULL)
  {
    return 1;
  }
 
  search_node * hold = head -> get_next(); 
  
  delete [] head -> name;
  delete head;
  head = hold;
  deletion_search(head);
  
  return 0;
}



// Search node get next function
search_node * & search_node::get_next()
{
  return next;
}


// Search node set next
void search_node::set_next(search_node * & temp)
{
  this -> next = temp;
}


// Fills each of the as either
// a Housing, Provisions, or clothing node.
void search_node::read(int selection)
{

  char temp_h[8] = "Housing";
  char temp_p[11] = "Provisions";
  char temp_c[9] = "Clothing";

  if(selection == 1)
  {
    name = new char[8];
    strcpy(name,temp_h);
    frequency = 0;
    return;
  }
      
  if(selection == 2)
  {
    name = new char[11];
    strcpy(name,temp_p);
    frequency = 0;
    return;
  }

  if(selection == 3)
  {
    name = new char[9];
    strcpy(name,temp_c);
    frequency = 0;
    return;
  }

  frequency = selection; 
}




//Displays the names and amount of searches
//each of nodes have.
int search_node::display(search_node * head)
{
	 
  if(head == NULL)
    return 0;

  cout << endl << head -> name 
       << " has " << head -> frequency 
       << " searches." << endl;
 
  display(head -> next);

  return 0;
}



// Retrieves frequency of the node
int search_node::check_freq()
{
  return frequency;
}



// Compares passed array to nodes data, increases frequency if match
int search_node::check(char temp[])
{
  if(strcmp(temp,name) == 0)
  {
    ++frequency;
    return 1;
  }

  return 1;
}




// Loops through LLL to compare all nodes for frequency
int search_node::increase_frequency(char temp[], search_node * & head)
{
  if(head == NULL)
    return 0;
 
  int result = head -> check(temp);
  
  increase_frequency(temp, head -> next);
  return 0;
}




// Compares the name of the node to the passed array and copies information
// into the array and sends it back to the user.
int search_node::retrieve(search_node * head, char copy_name[])
{

  if(head == NULL)
    return 0;  

  if(strcmp(copy_name,head -> name) == 0)
  {
    return head -> frequency;
  }

  search_node * temp_head = head -> get_next();;
  retrieve(temp_head, copy_name);
  
  return 0;
}



// Removes all of the nodes and deallocates all
// the memeory in the list if the user wishes
// to "turn off" the history.
int search_node::Remove_All(search_node * & head)
{
  if(head == NULL)
    return 0;

  search_node * hold = head -> get_next();
  delete [] head -> name;
  head = hold; 
  Remove_All(head);

  return 0;
}




// "Clears" the history and resets all of
// the frequency of each node to 0.
int search_node::reset(search_node * & head)
{
  if(head == NULL)
   return 0;

  head -> frequency = 0;
  search_node * temp_head = head -> get_next();

  reset(temp_head);

  return 0;
}




// This function sorts the LLL by frequency of how many times each option is chosen
// Everytime the frequency of the nodes change, this funciton will
// sort the LLL so the node with the highest frequency will be at the front
// and the lowest at the end.
int search_node::search_sort(search_node * & head)
{
  // Total Frequency of Each of the three nodes 
  int total_first = 0;
  int total_second = 0;
  int total_third = 0;

  // Used to call function, One for each of the three nodes
  search_node * first = head;
  search_node * second = head -> get_next();
  search_node * third  = second -> get_next();
 
  // Holds the posistions of each nodes,
  // So they can be manipulated easily
  // every time the order of the list needs
  // to change. 
  search_node * hold_first = first;
  search_node * hold_second = second;
  search_node * hold_third = third;
  search_node * end = NULL;

  // Obtain the frequencies of each node
  total_first = first -> check_freq();
  total_second = second -> check_freq();
  total_third = third -> check_freq();

  
  // The second node is largest
  if(total_second > total_first && total_second > total_third)
  {
    head = second;
  
     // If the first node is then second, and the third last
    if(total_first > total_third)
    {	    
      second -> set_next(hold_first);
      first -> set_next(hold_third);    
      third -> set_next(end);
    }

    // Or the opposite is the case
    else
    {
      second -> set_next(hold_third);
      third -> set_next(hold_first);
      first -> set_next(end);
    }
    return 0;
  }


  // If the third node is the largest
  if(total_third > total_second && total_third > total_first)
  {
    head = third;
  
    //If the first node is second largest, then the second node is last
    if(total_first > total_second)
    {	    
      third -> set_next(hold_first);
      first -> set_next(hold_second);    
      second -> set_next(end);
    }

    // Or the opposite is the case for the first and third
    else
    {
      third -> set_next(hold_second);
      second -> set_next(hold_first);
      first -> set_next(end);
    }
    return 0;
  }

  // If the first is still the largest but the second and last
  // need to switch positions
  if(total_first > total_third && total_first > total_second)
  {
    first -> set_next(third);
    third -> set_next(second);
    second -> set_next(end);
    return 0;
  }

  return 0;
}


//SEARCH HISTORY LIST IMPLEMENTATION
//
//
//



// Constructor
search_list::search_list()
{
  head = NULL;
}


// Search List Deconstructor
// Calls deletion functin
search_list::~search_list()
{
  Wrapper_deletion_search();
}


// Increase Frequency Wrapper Function
int search_list::increase(char temp[])
{
  search_node * current = head; 
  head -> increase_frequency(temp,head);    

  return 0;
}





// Sorting Wrapper Function
int search_list::Sort()
{
  head -> search_sort(head);
  return 0;
}
   

// This Function creates each of teh nodes in the LLL
// Based of the integer passed, this function will
// call a separate function that will designate
// the node as either Housing, Clothing, or Provisions
void search_list::Add(int selection)
{
  search_node * hold;
  search_node * temp;
  search_node * end; 

  // Empty List 
  if(head == NULL)
  { 
    head = new search_node;
    end = head -> get_next();
    end = NULL;
    head -> set_next(end);
    head -> read(selection);
    return;
  }
  
  else
  {
    end = NULL;
    temp = new search_node; 
    temp -> set_next(head);
    temp -> read(selection);  
    head = temp; 
    
    return;
  }

  return;

}


// Wrapper for Display Function
int search_list::Wrapper_display()
{
  cout << "\n\nSearch History is Displayed By frequency" << endl;
  search_node * temp;
  temp -> display(head);

  return 1;
}




// Wrapper for deletion function
int search_list::Wrapper_deletion_search()
{
  
  head -> deletion_search(head);

  return 0;
}



// Wrapper for remove all function
int search_list::Wrapper_Remove_All()
{
  head -> Remove_All(head);
  
  cout << "**\n\nSearch History Cleared and set to off**" << endl;
  return 0;
}





// Wrapper for reset history funciton
int search_list::Reset_History()
{
  head -> reset(head); 
  cout << "\n\n**Search History Cleared**" << endl;

  return 0;
}



// Wrappe for the retrieval function
int search_list::Retrieve_search(char copy_name[])
{
  int results = head -> retrieve(head,copy_name);
  return results;
}
