// header file
//
//
//

#include<iostream>
#include<cctype>
#include<cstring>
using namespace std;


// BASE CLASS
class relief
{

    public:
	    relief();                       // Constructor
	    ~relief();                      // Deconstructor
	    relief(const relief & to_copy); // Copy Constructor
	    void creation();                // Reads in from user for Data members
            int alter();                    // User can change their infor
	    void display();                 // Displays Data
	    int change_name();           
	    int change_address();
	    int change_dependants(); 
    protected:
    
            int age;                 // Age of user
	    int number_of_dependants;// Number of dependants
	    char * full_name;        // Name of User
	    char * address;          // User Address
	    char * zip;              // User Zip

};



// PROVISIONS CLASS
// DERIVED FROM RELIEF
class provisions: public relief
{
    public:
	  provisions();                          // Constructor
	  ~provisions();                         // Deconstructor
          provisions(const provisions & to_copy);// CC
	  void creation(int flag);               // Calls Relief Creation Function
	  void alter();	
	  void read();                           // Reads in data members from user
	  void read(provisions & object);        // Used to copy data for retrieval
	  void display();                        // Displays data and Base Class data
	  void display(int num);                 // Displays only own data
	  int comparison(char temp[]);           // Compares for match with array

    protected:
          int expiration_date;  // Expiration of food
	  char * food_name;     // Name of food
};

class housing: public relief
{
    public:
           housing();                       // Constructor
           ~housing();                      // Deconstructor
	   housing(const housing & to_copy);// CC
	   void creation(int flag);         // Calls Relief Creation Function
	   void alter();	
	   void display();                  // Displays data and Base Class data
	   void display(int num);           // Displays only own data
	   void read();                     // Reads in Data members from User
	   void read(housing & object);     // Used to copy for retrieval
	   int comparison(char temp[]);     // Compares for match with arrray
    protected:
           char * street;  // Street of housign
	   char * zip;     // Zip of housing
	   char * city;    // City of Housing
	   int rooms;      // Number of Rooms
};

class clothing: public relief
{
    public:
	    clothing();                         // Constructor
	    ~clothing();                        // Deconstructor
	    clothing(const clothing & to_copy); //CC
	    void creation(int flag);            // Calls Relief Creation Function
	    void alter();	
	    int comparison(char temp[]);        // Compares for match witha array
	    void display();                     // Displays data and Base Class data
	    void display(int num);              // Displays only own data
	    void read();                        // Reads in Data members from User
	    void read(clothing & object);       // Used to copy for retrieval
    protected:
	    char * clothing_name;    // Clothing name
	    float size;              // Size of clothing
	    char * weather_category; // Weather Category

};


