#include"node.h"
// Channer Bok Housing.cpp Program 1
// This file contains all of the functions that manage and use the Housing CLL



// Constructor for housing node
housing_node::housing_node()
{

}

//Deconstructor
//All memory is delete using the List Class deconstructor
//and the deletion Function Below
housing_node::~housing_node()
{
}


// Deletes CLL
int list::deletion_housing(housing_node * & current,housing_node * rear)
{
  if(current == rear)
  {
    delete current;
    return 1;
  }
 
  housing_node * hold = current -> get_next(); 
  
  delete current; 
  current = hold;
  deletion_housing(current,rear);

 return 0;
}



// Get next for housing node
housing_node *& housing_node::get_next()
{
  return next;
}



// Set Next
void housing_node::set_next(housing_node * & temp)
{
  this -> next = temp;
}



// Adds a node to the housing CLL
int list::Add_housing()
{
  housing_node * hold;  
  housing_node * temp;

  if(housing_rear == NULL)
  { 
    housing_rear = new housing_node;
    housing_rear->housing::creation(1);
  //  housing_rear->housing::alter();
    housing_rear -> read();
    housing_rear -> set_next(housing_rear);  
    return 1;
  }
  
  else
  {
    hold = housing_rear -> get_next();
    temp = new housing_node;
    temp->housing::creation(1);
    temp -> read();
    temp -> set_next(hold);  
    housing_rear -> set_next(temp);
  }

  return 0;
}


// Displays the node whose name matches the passsed data
int list::Display_Type(housing_node * current, housing_node * rear,char street[])
{
  int results = 0;

  if(current == rear)
  {
    results = current -> comparison(street);
  
    if(results == 1)
    {
      current -> display();
    }
 
    return 1;
  }

  results = current -> comparison(street);

  if(results == 1)
  {
    current -> display();
    return 1;
  }

  current = current -> get_next();
  Display_Type(current,rear,street);

  return 1;
}


// Finds the match for the passed array and copies that nodes into the passed obejct and sends it back
int list::Retrieve(housing_node * current, housing_node * rear, char street_name[], housing & object)
{
  int results = 0;

  if(current == rear)
  {
    results = current -> comparison(street_name);

    if(results == 1)
    {
      current -> read(object);
      return 1;
    }

    return 0;
  }

  results = current -> comparison(street_name);

  if(results == 1)
  {
    current -> read(object);
    return 1;
  }

  current = current -> get_next();
  Retrieve(current,rear,street_name,object);

  return 0;
}




// Displays all nodes in the CLL
int list::Display_All(housing_node * front, housing_node * rear)
{
  if(front == rear)
  {
    front -> display();
    return 1;
  }

  front -> display();
  front = front -> get_next();
  Display_All(front,rear);

  return 0;
}


//Removes the node that matches the passed array
int list::Remove_housing(housing_node * & front,char name[], housing_node *& rear, housing_node *& previous)
{
  int result;

  housing_node * temp;
  housing_node * hold;
  result = front -> comparison(name);  
  if(result == 1)
  {
    hold = front -> get_next();
    temp = rear -> get_next();

    if(hold == temp)
    {
      hold = rear -> get_next();
      previous -> set_next(hold);
      rear = previous;
      rear -> set_next(hold); 
      front -> housing::creation(0);
     // delete front;
      return 1;
    }

    temp = front -> get_next();
    previous -> set_next(temp); 
    front -> housing::creation(0);
    //delete front; 

    return 1;
  }

  if(front == rear)
  {
    return 1;
  }
  
  front = front -> get_next();
  previous = previous -> get_next();
  Remove_housing(front,name,rear,previous);
  
  return 0;
}






