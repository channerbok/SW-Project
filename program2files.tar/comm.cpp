// Channer Bok Program 2 application classes implementation .cpp file
// This file implements the discord, messenger, and gmail classes.
// Amongst their normal classes, there are also several virtual functions
// from my ABC that are standardized accross the seperate applications.



#include"node_2.h"



// ABC contrusctor
communication::communication()
{


}

// ABC deconstructor
communication::~communication()
{


}




//Discord Class



// Copy Constructro
discord::discord(const discord & object)
{
  if(object.message != NULL)
  {
    message = new char[strlen(object.message) + 1];
    strcpy(message,object.message);
  }

  if(object.recipient != NULL)
  {
    recipient = new char[strlen(object.recipient) + 1];
    strcpy(recipient,object.recipient);
  }

  if(object.time != NULL)
  {
    time = new char[strlen(object.time) + 1];
    strcpy(time,object.time);
  }

}



// Constructor
discord::discord()
{
  message = NULL;
  recipient = NULL;
  time = NULL;
}

// Deconstructor
discord::~discord()
{
  delete [] message;
  delete [] recipient;
  delete [] time;
}



// Copies data into discord members
int discord::set(int selection, char temp_message[], char temp_name[], char temp_time[])
{
  message = new char[strlen(temp_message) + 1];
  strcpy(message,temp_message);

  recipient = new char[strlen(temp_name) + 1];
  strcpy(recipient,temp_name);

  time = new char[strlen(temp_time) + 1];
  strcpy(time, temp_time);

  message_type = selection;

  if(selection == 2)
  {
    cout <<  "\nMessage from " << recipient << ":" 
         << endl << endl << message << endl
         << "\n\nTime: " << time << endl;
  }

  return 0;
}



// Prompts user for input to send message to add it to the message list
void discord::send_message(char temp_message[], char temp_name[], char temp_time[]) 
{
  cout << "\nPlease enter the name of the recipient" << endl;
  cin.get(temp_name,100,'\n');
  cin.ignore(100,'\n');
       
  cout << "\nPlease enter the message" << endl;
  cin.get(temp_message,100,'\n');
  cin.ignore(100,'\n');

  cout << "\nPlease enter the time" << endl;
  cin.get(temp_time,100,'\n');
  cin.ignore(100,'\n');

  return;

}



// Prompts user for info on who the message is coming from
void discord::read_message(char temp_message[], char temp_name[], char temp_time[])  
{
  int selection;
  char family[170] = "\nHey there!\n We are looking forward to dinner on next Tuesday. Love you.";
  char friends[170] = "\nDo you want to go downtown and get some Kombucha? Let me know!";
  char colleague[170] = "\nThere will be a meeting in the conference room at 12:00 pm tommorrow.";
  
  
  cout << "\nPlease enter the name of whose message you want to check for" << endl;
  cin.get(temp_name,100,'\n');
  cin.ignore(100,'\n');
       
  cout << "\nWhat is your affiliation with them?" << endl
       << "\n1. Family"
       << "\n2. Friend"
       << "\n3. Colleague"
       << endl;
  cin >> selection;
  cin.ignore(100,'\n');

  if(selection == 1)
    strcpy(temp_message,family); 

  if(selection == 2)
    strcpy(temp_message,friends); 
  
  if(selection == 3)
    strcpy(temp_message,colleague); 


  cout << "\nPlease enter the time" << endl;
  cin.get(temp_time,100,'\n');
  cin.ignore(100,'\n');

  return;
}




// Promts user for who the message was to/from
void discord::remove_message(char temp_name[])
{
  cout << "\n\nWhat is the name of the of the person you "
       << "\nsent or received the message from?" << endl;

  cin.get(temp_name,30,'\n');
  cin.ignore(100,'\n');
}



void discord::open()
{
  cout << "\nAccount has been initialized" << endl;
}


	
int discord::channel(int & channel, char temp_message[], char temp_name[], char temp_time[])
{
  cout << "\nWelcome Discord Threads"  
       << "\nThis helps you maintain a Discord thread"
       << endl << endl;
  
  cout << "\n1. Create Thread (you may only create one total)"
       << "\n2. Add to thread"
       << "\n3. View Thread"
       << "\n4. Quit"<< endl;

  cin >> channel;
  cin.ignore(100,'\n');
  
  if(channel == 1 || channel == 2)
  {
    cout << "\n\nPlease enter the name of whose message you wish to respond too" << endl;
    cin.get(temp_name,30,'\n'); 
    cin.ignore(100,'\n');

    cout << "\n\nPlease enter the body of the message for the thread" << endl;
    cin.get(temp_message,30,'\n'); 
    cin.ignore(100,'\n');

    cout << "\n\nPlease enter the time of the sent message" << endl;
    cin.get(temp_time,30,'\n'); 
    cin.ignore(100,'\n');
    return 1;
  }

  if(channel == 3)
    return 1;

  return 0;
}





//Messenger Class
// Constructor
messenger::messenger()
{
  message = NULL;
  recipient = NULL;
  time = NULL;
  signature = NULL;
}


// Deconstructor
messenger::~messenger()
{
 delete [] message;
 delete [] recipient;

 if(time != NULL)
   delete [] time;

 if(signature != NULL)
   delete [] signature;
}

messenger::messenger(const messenger & source)
{
  if(source.message != NULL)
  {
    message = new char[strlen(source.message) + 1];
    strcpy(message,source.message);
  }

  if(source.recipient != NULL)
  {
    recipient = new char[strlen(source.recipient) + 1];
    strcpy(recipient,source.recipient);
  }

  if(source.time != NULL)
  {
    time = new char[strlen(source.time) + 1];
    strcpy(time,source.time);
  }
  
  if(source.signature != NULL)
  {
    signature = new char[strlen(source.signature) + 1];
    strcpy(signature,source.signature);
  }
}



// Copies data into messenger  members
int messenger::set(int selection, char temp_message[], char temp_name[], char temp_time[])
{
  message = new char[strlen(temp_message) + 1];
  strcpy(message,temp_message);

  recipient = new char[strlen(temp_name) + 1];
  strcpy(recipient,temp_name);

  time = new char[strlen(temp_time) + 1];
  strcpy(time, temp_time);

  signature = new char[strlen(temp_time) + 1];
  strcpy(signature, temp_time);

  message_type = selection;

  if(selection == 2)
  {
     cout <<  "\nMessage from " << recipient << ":" 
	  << endl << endl << message << endl
	  << "\n\nTime: " << time << endl;
  }
  return 0;
}


// Prompts user for input to send message
void messenger::send_message(char temp_message[], char temp_name[], char temp_time[])
{
  cout << "\nPlease enter the name of the recipient" << endl;
  cin.get(temp_name,100,'\n');
  cin.ignore(100,'\n');
       
  cout << "\nPlease enter the message" << endl;
  cin.get(temp_message,100,'\n');
  cin.ignore(100,'\n');

  cout << "\nPlease enter your signature for the bottom of the message" << endl;
  cin.get(temp_time,100,'\n');
  cin.ignore(100,'\n');

  return;
}




// Prompts user for input on who is sending the message
void messenger::read_message(char temp_message[], char temp_name[], char temp_time[])  
{
  // Local Variables
  int selection;

  // Canned messages to receive
  char family[170] = "\nWe just bought you a new Subaru, enjoy your new Outback!";
  char friends[170] = "\nLets meet up on campus for some coffee and bagels.";
  char colleague[170] = "\nThe printer is out of ink, we will not have any until nex Tuesday.";


  cout << "\nPlease enter the name of whose message you want to check for" << endl;
  cin.get(temp_name,100,'\n');
  cin.ignore(100,'\n');
       
  cout << "\nWhat is your affiliation with them?" << endl
       << "\n1. Family"
       << "\n2. Friend"
       << "\n3. Colleague"
       << endl;
  cin >> selection;
  cin.ignore(100,'\n');

  if(selection == 1)
    strcpy(temp_message,family); 

  if(selection == 2)
    strcpy(temp_message,friends); 
  
  if(selection == 3)
    strcpy(temp_message,colleague); 

  cout << "\nPlease your the time" << endl;
  cin.get(temp_time,100,'\n');
  cin.ignore(100,'\n');

  return;
}



// Promts user for who the message was to/from
void messenger::remove_message(char temp_name[])
{
  cout << "\n\nWhat is the name of the of the person you "
       << "\nsent or received the message from?" << endl;

  cin.get(temp_name,30,'\n');
  cin.ignore(100,'\n');
}



// Displays message to user
void messenger::open()
{
  cout << "\nAccount has been initialized" << endl;
}




// Gmail Class


// Constructor
gmail::gmail()
{
 message = NULL; 
 recipient = NULL;
 subject  = NULL;
}


// Deconstructor
gmail::~gmail()
{
 delete [] message;
 delete [] recipient;
 delete [] subject;
}



gmail::gmail(const gmail & source)
{
  if(source.message != NULL)
  {
    message = new char[strlen(source.message) + 1];
    strcpy(message,source.message);
  }

  if(source.recipient != NULL)
  {
    recipient = new char[strlen(source.recipient) + 1];
    strcpy(recipient,source.recipient);
  }

  if(source.subject != NULL)
  {
    subject = new char[strlen(source.subject) + 1];
    strcpy(subject,source.subject);
  }
}




// Copies data into gmail  members
int gmail::set(int selection, char temp_message[], char temp_name[], char temp_time[])
{
  message = new char[strlen(temp_message) + 1];
  strcpy(message,temp_message);

   recipient = new char[strlen(temp_name) + 1];
  strcpy(recipient,temp_name);

  subject = new char[strlen(temp_time) + 1];
  strcpy(subject, temp_time);

  message_type = selection;

  if(selection == 2)
  {
     cout <<  "\nMessage from " << recipient << ":" 
	  << endl << endl << message << endl
	  << "\n\nTime: " << time << endl;
  }

  return 0;

}



// Prompts user for input to send message
void gmail::send_message(char temp_message[], char temp_name[], char temp_time[])
{
  cout << "\nPlease enter the name of the recipient" << endl;
  cin.get(temp_name,100,'\n');
  cin.ignore(100,'\n');
       
  cout << "\nPlease enter the message" << endl;
  cin.get(temp_message,100,'\n');
  cin.ignore(100,'\n');

  cout << "\nPlease enter the time" << endl;
  cin.get(temp_time,100,'\n');
  cin.ignore(100,'\n');

  return;
}



// Prompts user for input to read a new message
void gmail::read_message(char temp_message[], char temp_name[], char temp_time[])
{
  // Local Variables
  int selection;
  char family[170] = "\nWe are having lasagna for dinner, bring your appetite!";
  char friends[170] = "\nHappy Birthday!";
  char colleague[170] = "\nYou got the promotion, congratulations!.";

  cout << "\nPlease enter the name of whose message you want to check for" << endl;
  cin.get(temp_name,100,'\n');
  cin.ignore(100,'\n');
       
  cout << "\nWhat is your affiliation with them?" << endl
       << "\n1. Family"
       << "\n2. Friend"
       << "\n3. Colleague"
       << endl;
  cin >> selection;
  cin.ignore(100,'\n');

  if(selection == 1)
    strcpy(temp_message,family); 

  if(selection == 2)
    strcpy(temp_message,friends); 
  
  if(selection == 3)
    strcpy(temp_message,colleague); 

  cout << "\nPlease enter the Email Subject Line" << endl;
  cin.get(temp_time,100,'\n');
  cin.ignore(100,'\n');

  return;
}
  

// Prompts user for name to delete from LLL
void gmail::remove_message(char temp_name[])
{
  cout << "\n\nWhat is the name of the of the person you "
       << "\nsent or received the message from?" << endl;

  cin.get(temp_name,30,'\n');
  cin.ignore(100,'\n');
}


void gmail::open()
{
  cout << "\nAccount has been initialized" << endl;
}











