// Channer Bok Program 2 .h file for user, ABC, and the different messaging application classes.
// This file contains all of the classes for the different messaging apps as well as the 
// Abstract Base class for them to user.


#include<iostream>
#include<cctype>
#include<cstring>
using namespace std;



class user
{
  public:
	 user();
	 ~user();
	 user(const user & source);
	 int add_user();
         int check_name(char temp_name[], int selection);
	 int display_account();

 protected:
	 char * user_name;
	 char * password;
};


// ABC
class communication
{
  public:
        communication(); // Constructor
        virtual ~communication(); // Deconstructor
        virtual void send_message(char temp_message[], char temp_name[], char temp_time[])=0;
	virtual void read_message(char temp_message[], char temp_name[], char temp_time[])=0;  // Reads in messages from others
        virtual void remove_message(char temp_name[])=0;// Deletes a message
	virtual void open()=0;
};



// Discord Application Class
class discord: public communication
{
     public:
        discord();  // Constructor
        ~discord(); // Deconstructor
	discord(const discord & object); // Copy Constructor
        void send_message(char temp_message[], char temp_name[], char temp_time[]);        // Creates messenger LLL
	void read_message(char temp_message[], char temp_name[], char temp_time[]);        // Reads in messages from others
        void remove_message(char temp_name[]);                                             // Deletes a message
 	void open();                                                                       
	int set(int selection, char temp_message[], char temp_name[], char temp_time[]);   // Copies data into the list
	int channel(int & channel, char temp_message[], char temp_name[], char temp_time[]);// Creates threaded messages

  protected:
	char * message;  // Message Body
        char * time;     // Time of message
        char * recipient;// Who sent/received message
        int message_type;// Whether it was sent or received

};



// Messenger Application Class
class messenger: public communication
{
    public:
        messenger();  // Constructor
        ~messenger(); // Deconstructor
	messenger(const messenger & source);  // Copy Constructor
        void send_message(char temp_message[], char temp_name[], char temp_time[]);      // Creates messenger LLL
	void read_message(char temp_message[], char temp_name[], char temp_time[]);      // Reads in messages from others
        void remove_message(char temp_name[]);                                           // Deletes a message
	int set(int selection, char temp_message[], char temp_name[], char temp_time[]); // Copies data into the list
 	void open();           

  protected:
        char * message;  // Body of message
        char * signature;// Signature
	char  * time;    // Time of message
	char * recipient;// Who sent/received message
     	int message_type;// Used to track list
};



// Gmail Class
class gmail: public communication
{
    public:
        gmail(); // Constructor
        ~gmail();// Deconstructor
	gmail(const gmail & source);  // Copy Constructor
        void send_message(char temp_message[], char temp_name[], char temp_time[]);       // Creates messenger LLL
	void read_message(char temp_message[], char temp_name[], char temp_time[]);      // Reads in messages from others
        void remove_message(char temp_name[]);                                           // Deletes a message
	int set(int selection, char temp_message[], char temp_name[], char temp_time[]); // Copies data into the list
 	void open();           
	

  protected:
        char * message;  // Body of message
	char * subject;  // Subject Line of message
	char * recipient;// Who sent/received message
       	int message_type;// Used to track list

};

// Function prototype for menu interface
void main_menu();
