#include"program.h"
// Channer Bok program 2 node  and list class.h file 
// This file contains all of the different node classes for the LLL's and the list manager class





// LLL nodes Class for MESSENGER
class messenger_node:public messenger
{
     public:
	    messenger_node();  // Constructor
            ~messenger_node(); // Deconstructor
            messenger_node *& get_next(); // Get Next
            void set_next(messenger_node * & temp); // Set Next pointer

	    void deletion_mess(messenger_node *& head);          // Deallocates LLL
            int find(messenger_node * head, char source_name[]); // Search for name
	    void display(messenger_node * & head_m);             // Displays nodes
	    void remove_all(messenger_node * & head_m);          // Deletes All Nodes
	    void remove(messenger_node * & head_g, char name[]); // Deletes a node

  protected:
	  messenger_node * next;  // Next pointer


};


// LLL nodes Class for GMAIL  
class gmail_node: public gmail
{
     public:
	    gmail_node();  // Constructor
            ~gmail_node(); // Deconstructor
            gmail_node *& get_next();  // Get Next
            void set_next(gmail_node * & temp); // Set Next pointer

	    void deletion_gmail(gmail_node *& head);         // Deallocates LLL
	    void display(gmail_node * & head_g);             // Displays nodes
	    void remove_all(gmail_node * & head_g);          // Deletes LLL
	    void remove(gmail_node * & head_g, char name[]); // Deletes a node

  protected:
	  gmail_node * next; // Next pointer


};


// LLL nodes Class for DISCORD
class discord_node: public discord
{
     public:
	    discord_node();  // Constructor
            ~discord_node(); // Deconstructor
            discord_node *& get_next(); // Get Next
            void set_next(discord_node * & temp); // Set Next int send();
	    void deletion_discord(discord_node *& head, discord_node * & head_dtwo);      // Deallocates LLL
            int find(discord_node * head, char source_name[]);// Search for name
	    void display(discord_node * & head_d);            // Displays nodes
	    void remove_all(discord_node * & head_d);         // Deletes LLL
	    void remove(discord_node * & head_d, char name[]);// Deletes a node 

	    int create_thread(discord_node * & head_d,char name[], char message[], char time[], discord_node * & head_dtwo); // Creates thread LLL
	    int add_thread(discord_node * & head_dtwo, char name[], char message[], char time[]);                            // Adds to LLL
	    int view_thread(discord_node * & head_dtwo);                                            // Displays LLL
            void delete_thread(discord_node * & head_dtwo);


  protected:
	  discord_node * next; // Next Pointer
          

};



// LLL of communications pointer
// Houses ABC pointers
class node: public user
{
     public: 
	     node();                                              // Constructor
	     ~node();                                             // Deconstructor
	     node *& get_next();                                  // Get Next
             void set_next(node * & temp);                        // Set Next 
             int read(node* & head,int selection, char user_copy[], char pw_copy[]); // Gets user info
             int find(node *& head, char source_name[]);          // Search Function
             void node_deletion(node * & head);                   // Deletes a node
	     int display(node *& head);                           // Display LLL 
	     int Remove_All(node * & head);                       // Removes All Nodes
	     int remove(node * & head, char copy_name[], int & counter);         // Removes a node

     protected:
	     char * name;             // Name of Account
	     int account_number;      // Used for list index
	     discord * test_pointer;  // Used for RTTI
	     communication * pointer; // Used for Dynamic Binding
	     node * next;             // Next Pointer for LLL
	     class list * object;     // List pointer to call funcitons
             
};


class list
{
     public:
	    list();  // Constuctor
	    ~list(); // Deconstructor
            void Add(node* & head, int selection, char user_copy[], char pw_copy[]);                            // Add node, set user info
	    void Add_wrapper(int selection,char user_copy[], char pw_copy[]);                                   // Wrapper function to add a node
            int Use(char source_name[]);                                                                        // Access ABC LLL
            int Use(char source_name[], list & list_object, list & list_object_two, list & list_object_three);  // Access ABC LLL
            int find(char name[]);                                                                              // Finds Account 
	    int Wrapper_display(int selection);                                                                 // Wrapper for Display
            int Wrapper_Remove_All(int selection);                                                              // Wrapper for remove all
            int Remove(char name[], int selection);
            void Add(int selection, char temp_message[], char temp_name[], char temp_time[], int message_type); // Creates messenger LLL
            void Add_disc(int selection, char temp_message[],char temp_name[], char temp_time[]);               // Creates discord LLL for threaded messages



     protected:
	     node * head;              // Head of LLL for ABC pointers
	     messenger_node * head_m;  // Messenger LLL Head
	     gmail_node * head_g;      // Gmail LLL Head
             discord_node * head_d;    // Discord LLL Head
	     discord_node * head_dtwo; // Discord LLL Head for threaded messages

};

// Function Prototype for main menu Function in main.cpp
void main_menu();























