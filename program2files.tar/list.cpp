// Channer Bok Program 2 user, account node, and list class implementation .cpp file
// This file creates and manages all of the user's information.
// It also creates and manages the nodes that are used in the LLL
// of communication pointers. Finally it implements the list
// class that manages all of the data structures in the program.

#include"node_2.h"




//USER Class



// Constructor
user::user()
{
  user_name = NULL;
  password = NULL;
}



// Deconstructor
user::~user()
{
  delete [] user_name;
  delete [] password;
}


user::user(const user & source)
{
  if(source.user_name != NULL)
  {
    user_name  = new char[strlen(source.user_name) + 1];
    strcpy(user_name,source.user_name);
  }

  if(source.password != NULL)
  {
    password  = new char[strlen(source.password) + 1];
    strcpy(password,source.password);
  }

}


// Prompts user for account information
int user::add_user()
{
  char temp_user[30];
  char temp_pw[20];

  cout << "\nPlease enter your user information: " 
       << "\nUser name: " 
       << endl; 
  cin.get(temp_user,30,'\n');
  cin.ignore(100,'\n');

  cout << "\nPassword: " << endl;
  cin.get(temp_pw,30,'\n');
  cin.ignore(100,'\n');

  user_name = new char[strlen(temp_user) + 1];
  strcpy(user_name,temp_user);
 
  password = new char[strlen(temp_pw) + 1];
  strcpy(password,temp_pw);

  return 0;
}
	    
int user::display_account()
{
  cout << "\n\n\n\nThe user name is " << user_name << endl
       << "The password is " << password << "\n\n\n\n\n" << endl;

  return 1;
}





// Node Class


// Constructor
node::node()
{
  next = NULL;
}


// Deconstructor
node::~node()
{

}



// Delections the LLL
void node::node_deletion(node * & head)
{
  if(head == NULL)
  {
    return;
  } 

  node * temp = head -> get_next();
  delete head -> pointer;
  delete head -> object;
  delete head;

  node_deletion(temp);
}



// Gets next pointer
node *& node::get_next()
{
  return next;
}
            


// Sets next pointer
void node::set_next(node * & temp)
{
  this -> next = temp;
}




// Dynamic Binding function to set communication pointers to one
// of the three applications
int node::read(node * & head, int selection, char user_copy[], char pw_copy[])
{
  head -> add_user();

  if(selection == 3)
  {
    pointer = new discord;
    account_number = selection;
  }

  if(selection == 1)
  {
    pointer = new messenger;
    account_number = selection;
  }

  if(selection == 2)
  {
    pointer = new gmail;
    account_number = selection;
  }
  
  object = new list;
  return account_number;
 }

  

// Menu interface for using the messaging applications
// The function will search through the LLL to find the matching account,
// then will access it and call virtual functions.
int node::find(node * & head, char source_name[])
{
  int selection = 0;
  int channel  = 0;
  char temp_message[100];
  char temp_name[30];
  char temp_time[10];

  if(head == NULL)
  {
    cout << "NOT FOUND" << endl;
    return 0;
  }

  int result = head -> check_name(source_name,selection);

  if(result == 1)
  {
    while(selection != 8)
    {
      cout << "\nWelcome to your account"
           << "\nPlease choose an option from the following."
	   << "\n1. Initiate the account"
	   << "\n2. Send a message"
	   << "\n3. Read a message"
	   << "\n4. Read all messages"
	   << "\n5. Delete a Message"
	   << "\n6. Remove all messages" 
	   << "\n7. Create a thread (Discord Only)"
	   << "\n8. Quit"
	   << endl;
      cin >> selection;
      cin.ignore(100,'\n');
      

      // Virtual Function
      if(selection == 1)
        pointer -> open();

      // Virtual Function
      if(selection == 2)
      {
        pointer -> send_message(temp_message,temp_name,temp_time);
        object -> Add(account_number,temp_message,temp_name,temp_time,1);
      }


      // Virtual Function
      if(selection == 3)
      {
        pointer -> read_message(temp_message,temp_name,temp_time);
        object -> Add(account_number,temp_message,temp_name,temp_time,2);
      }

      if(selection == 4)
      {
        cout << "\nDisplaying all messages:\n\n\n" << endl;
        object -> Wrapper_display(account_number);
      }

      
      // Virtual Function
      if(selection == 5)
      {
        pointer -> remove_message(temp_name);
        object -> Remove(temp_name,account_number);
      }
     

      if(selection == 6)
      {
        cout << "\n\n**Initiating Message Deletion**" << endl;
        object -> Wrapper_Remove_All(account_number);
	cout << "\n\n**Deletion Complete**" << endl;
      }
     

      // RTTI Used here 
      if(selection == 7)
      {
        test_pointer = dynamic_cast<discord*>(pointer); 
	if(test_pointer)
        { 
          test_pointer = new discord;
	  test_pointer -> channel(channel,temp_message,temp_name,temp_time);

	  if(channel != 0)
            object -> Add_disc(channel,temp_message,temp_name,temp_time);

	  delete test_pointer;
	}
	else
	cout << "This is not a discord account" << endl;
      }
    }

    return 0;
  }

  find(head -> next, source_name);
  return 0;
}



// Displays account LLL
int node::display(node *& head)
{
  if(head == NULL)
    return 0;

  head -> display_account();
  node * forward = head -> get_next();

  display(forward);
 
 return 1;
}
	    


// Deletes account LLL
int node::Remove_All(node * & head)
{
  if(head == NULL)
  {
    return 1;
  }

  node * hold = head -> get_next();
  delete head -> pointer;
  delete head;

  head = hold;

  Remove_All(head);

  return 1;
}


// Compares passed name to account name
int user::check_name(char temp_name[],int selection)
{
  if(strcmp(user_name, temp_name) == 0)
  {
    cout << "Credentials Verified" << endl;
    return 1;
  }
  else 
    return 0;


  return 0;
}



	     
// Removr an account 
int node::remove(node * & head, char copy_name[], int & counter)
{
  int result; 
  int selection = 99;
  node * hold;
  node * forward;
  node * removal;

  if(head == NULL)
  {
    cout << "\nAccount not found!" << endl;    
    return 1;
  }
 
  if(counter == 0)
  {
    result = head -> check_name(copy_name,selection);
    if(result == 1)
    {
       forward = head -> get_next();
       removal = head;
       head = forward;
       delete removal -> pointer;
       delete removal -> object;
       delete removal;
       return 1; 
    }
  }

  
  forward = head -> get_next();
  result = forward -> check_name(copy_name,selection);

  if(result == 1)
  {
    removal = forward;
    hold = forward -> get_next();
    head -> set_next(hold);

    delete removal -> pointer;
    delete removal -> object;
    delete removal;
    
    if(head == NULL)
    {
      return 0;      
    }

    else
      return 1;
  } 

  ++counter;
  node * second = head -> get_next();
  remove(second,copy_name,counter);
  
  
  return 1;
}	    
	     



// List Class

// Constructor
list::list()
{
  head_m = NULL;
  head_g = NULL;
  head_d = NULL;
  head_dtwo = NULL;
  head = NULL;
}



// Deconstructor
list::~list()
{
  head -> node_deletion(head);
  head_m -> deletion_mess(head_m);
  head_g -> deletion_gmail(head_g);
  head_dtwo -> delete_thread(head_dtwo);
  head_d -> deletion_discord(head_d,head_dtwo);
}





// Wrapper for add account class
void list::Add_wrapper(int selection,char user_copy[], char pw_copy[])
{
  Add(head,selection,user_copy,pw_copy);
}



// Adds a node to the Communication LLL
void list::Add(node * & head, int selection, char user_copy[], char pw_copy[])
{
  node * end = NULL;
  node * temp;
  if(head == NULL)
  {
    temp = new node;
    temp -> set_next(end);
    temp -> read(temp,selection,user_copy,pw_copy);
    head = temp;
    return;
  }
 
  if(head -> get_next() == NULL) 
  {
    temp = new node;
    head -> set_next(temp);
    temp -> set_next(end);
    temp -> read(temp,selection,user_copy,pw_copy);
    return;
  }

  node * forward = head -> get_next();
  Add(forward,selection,user_copy,pw_copy);

  return;
}


  

// Wrapper to find account name match
int list::Use(char source_name[])
{
  head -> find(head,source_name);
  return 1;
}



// Adds a node to the messages LLL for one of the three different apps
void list::Add(int selection, char temp_message[], char temp_name[], char temp_time[], int message_type)
{

  // Messenger LLL
  if(selection == 1)
  {
    messenger_node * temp;
    messenger_node * hold = NULL;

    if(head_m == NULL)
    {
      head_m = new messenger_node;
      head_m -> set_next(hold);
      head_m -> set(message_type,temp_message,temp_name,temp_time);
      return;
    }
  
    temp = new messenger_node;
    temp -> set_next(head_m);
    temp -> set(message_type,temp_message,temp_name,temp_time);
    head_m = temp;

    return;
  }
 

  // Gmail LLL 
  if(selection == 2)
  {
    gmail_node * temp;
    gmail_node * hold = NULL;

    if(head_g == NULL)
    {
      head_g = new gmail_node;
      head_g -> set_next(hold);
      head_g -> set(message_type,temp_message,temp_name,temp_time);
      return;
    }
    temp = new gmail_node;
    temp -> set_next(head_g);
    temp -> set(message_type,temp_message,temp_name,temp_time);
    head_g = temp;
    return;
  }
 

  // Discord LLL 
  if(selection == 3)
  {
    discord_node * temp;
    discord_node * hold = NULL;

    if(head_d == NULL)
    {
      head_d = new discord_node;
      head_d -> set_next(hold);
      head_d -> set(message_type,temp_message,temp_name,temp_time);
      return;
    }
    temp = new discord_node;
    temp -> set_next(head_d);
    temp -> set(message_type,temp_message,temp_name,temp_time);
    head_d = temp;
    return;
  }
}


	    



// Add a threaded message
void list::Add_disc(int selection, char temp_message[], char temp_name[], char temp_time[])
{
  if(head_d == NULL)
  {
    cout << "\n\nThere are no messages to create a thread for." << endl;
    return;
  }
  
  if(head_dtwo == NULL)
  {
    if(selection == 1)
      head_d -> create_thread(head_d,temp_name,temp_message,temp_time,head_dtwo);
    else
     cout << "\nError! You are only allowed to make one threaded message board. \nTry adding to your previous thread instead" << endl;
  }

  if(selection == 2)
    head_d -> add_thread(head_dtwo,temp_name,temp_message,temp_time);

  if(selection == 3)
  {
    head_d -> view_thread(head_dtwo); 
  }

  return ;
}
            


// Calls Messages LLL display function
int list::Wrapper_display(int selection)
{
  int counter = 0;

  // Messenger
  if(selection == 1) 
    head_m -> display(head_m);

  // Gmail
  if(selection == 2) 
    head_g -> display(head_g);

  // Discord
  if(selection == 3) 
    head_d -> display(head_d);

  // Account
  if(selection == 4)
   head -> display(head);


 return 1;
}
           

// Calls messages remove all
int list::Wrapper_Remove_All(int selection)
{
  // Messenger
  if(selection == 1) 
    head_m -> remove_all(head_m);

  // Gmail
  if(selection == 2) 
    head_g -> remove_all(head_g);
 
  // Discord and threaded messages 
  if(selection == 3) 
  {
    head_d -> remove_all(head_d);

    if(head_dtwo != NULL)
       head_dtwo -> remove_all(head_dtwo);
  }
 
  // Account 
  if(selection == 4)
  {
    head -> node_deletion(head);
    head = NULL;
  }

  return 1;
}




// Calls messages remove 
int list::Remove(char name[], int selection)
{
  int counter = 0;

  // Messenger
  if(selection == 1) 
    head_m -> remove(head_m,name);

  // Gmail
  if(selection == 2) 
    head_g -> remove(head_g,name);
 
  // Discord 
  if(selection == 3) 
    head_d -> remove(head_d,name);

  // Account
  if(selection == 4) 
    head -> remove(head,name,counter);

  return 1;

}
            
