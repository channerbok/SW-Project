// Channer Bok Program 2 applications node class implementations .cpp file
// This file implements all three of the node classes that are used
// in each of the messaging apps LLL of messages.


#include"node_2.h"

// Discord Node Class


// Constructor
discord_node::discord_node()
{


}


// Deconstructor
discord_node::~discord_node()
{

}




// Deletes LLL
void discord_node::deletion_discord(discord_node * & head, discord_node * & head_dtwo)
{

  if(head == NULL)
  {
    return;
  } 

  discord_node * temp = head -> get_next();

  delete head;

  deletion_discord(temp,head_dtwo);
}


// Deallocates threaded messages
void discord_node::delete_thread(discord_node * & head_dtwo)
{

  if(head_dtwo == NULL)
  {
    return;
  } 

  discord_node * temp = head_dtwo -> get_next();
  delete head_dtwo;
  head_dtwo = NULL;

  delete_thread(temp);

}


// Creates threaded message LLL
int discord_node::create_thread(discord_node * & head_d,char name[], char message[], char time[], discord_node * & head_dtwo)
{
  discord_node * end = NULL;
  int type = 1;

  if(head_d == NULL)
  {
    cout << "\nThat message was not found" <<  endl;
    return 0;
  }

  if(strcmp(head_d -> recipient, name) == 0)
  {
    head_dtwo = new discord_node;
    head_dtwo -> set(type,message,name,time);
    head_dtwo -> set_next(end); 
    return 1;
  }

  discord_node * forward = head_d -> get_next();

  create_thread(forward,name,message,time,head_dtwo);

  return 1;
}



// Displays Threaded message LLL
int discord_node::view_thread(discord_node * & head_dtwo)
{
  if(head_dtwo == NULL)
  {
    cout << "\nNo messages" << endl;
    return 1;
  }

  head_dtwo -> display(head_dtwo);
 
  cout << "\nEnd of threaded messages" << endl;

  return 1;

}




// Adds a message to threaded message LLL
int discord_node::add_thread(discord_node * & head_dtwo, char name[], char message[], char time[])
{
  int type = 0;
  discord_node * end = NULL; 


  if(head_dtwo -> get_next() == NULL) 
  {
    discord_node * temp = new discord_node;
    head_dtwo -> set_next(temp);
    temp -> set_next(end);
    temp -> set(type,message,name,time);
    return 1;
  }

  discord_node * forward = head_dtwo -> get_next();
  

  add_thread(forward,name,message,time);

  return 1;
}



// Get next
discord_node *& discord_node::get_next()
{
 return next;
}




// Set next
void discord_node::set_next(discord_node * & temp)
{
  this -> next = temp;
}



// Displays all messages
void discord_node::display(discord_node * & head_d)
{
  if(head_d == NULL)
   return ;

  if(head_d -> message_type == 1)
    cout << "\nMessage @" << head_d -> recipient << ":" << endl;
  
  if(head_d -> message_type == 2)
    cout << "\nMessage from " << head_d -> recipient << ":" << endl;

  cout << endl << endl << head_d -> message << endl
       << "\nTime: " << head_d -> time << "\n\n\n\n\n\n\n" << endl;

  discord_node * temp;
  temp = head_d -> get_next();

  display(temp);
  return ; 
}

	   
	    
// Delete a message
void discord_node::remove(discord_node * & head_d, char name[])
{
  discord_node * end = NULL;

  if(head_d == NULL)
  {
    cout << "\nMessage not found!" << endl;    
    return;
  }

  if(strcmp(head_d -> recipient, name) == 0)
  {
    discord_node * remove = head_d;
    head_d = head_d -> get_next();
    delete remove;
    return ;      
  } 


  discord_node * forward = head_d -> get_next(); 
  if(forward == NULL)
    return;

  if(strcmp(forward -> recipient, name) == 0)
  {
    discord_node * temp = forward -> get_next();

    if(temp == NULL) 
    {
      head_d -> set_next(end);
      delete forward;
      return;
    }

    head_d -> get_next() = head_d -> get_next() -> get_next(); 
    delete forward;
    return;
  }

  discord_node * temp = head_d -> get_next();
  remove(temp,name);

  return;
}



// Deletes all messages
void discord_node::remove_all(discord_node * & head_d)
{
  if(head_d == NULL)
  {
    return;
  }

  discord_node * hold = head_d ->get_next();
  delete head_d;
  head_d = hold;

  remove_all(head_d);
}






// Messenger node class




// Constructor
messenger_node::messenger_node()
{


}

// Deconstructor
messenger_node::~messenger_node()
{

}


// Deletes LLL
void messenger_node::deletion_mess(messenger_node * & head)
{
  if(head == NULL)
  {
    return;
  } 

  messenger_node * temp = head -> get_next();
  delete head;

  deletion_mess(temp);
}



// Get next
messenger_node *& messenger_node::get_next()
{
 return next;
}



// Set next
void messenger_node::set_next(messenger_node * & temp)
{
  this -> next = temp;
}




// Displays all message
void messenger_node::display(messenger_node * & head_m)
{
  if(head_m == NULL)
   return ;

  if(head_m -> message_type == 1)
    cout << "\nMessage to " << head_m -> recipient << ":" << endl;
  
  if(head_m -> message_type == 2)
    cout << "\nMessage from " << head_m -> recipient << ":" << endl;

  cout << endl << endl << head_m -> message << endl << endl << endl << endl;


  if(head_m -> message_type == 2)
  cout << "\nTime: " << head_m -> time << "\n\n\n\n\n\n" << endl;

  else
  cout << head_m -> signature << "\n\n\n\n\n\n" << endl;


  messenger_node * temp;
  temp = head_m -> get_next();

  display(temp);
  return ; 
}

	   

// Deletes a message
void messenger_node::remove(messenger_node * & head_m, char name[])
{
  messenger_node * end = NULL;
 
  if(head_m == NULL)
  {
    cout << "\nMessage not found!" << endl;    
    return;
  }

  if(strcmp(head_m -> recipient, name) == 0)
  {
    messenger_node * remove = head_m;
    head_m = head_m -> get_next();
    delete remove;
    return ;      
  } 

  messenger_node * forward = head_m -> get_next(); 
  
  if(forward == NULL)
    return;

  if(strcmp(forward -> recipient, name) == 0)
  {
    messenger_node * temp = forward -> get_next();

    if(temp == NULL) 
    {
      head_m -> set_next(end);
      delete forward;
      return;
    }

    head_m -> get_next() = head_m -> get_next() -> get_next(); 
    delete forward;
    return;
  }

  messenger_node * temp = head_m -> get_next();
  remove(temp,name);

  return;
}




// Deletes all messages
void messenger_node::remove_all(messenger_node * & head_m)
{
  if(head_m == NULL)
  {
    return;
  }


  messenger_node * hold = head_m ->get_next();
  delete head_m;

  head_m = hold;

  remove_all(head_m);
}



// Gmail Node Class



// Constructor
gmail_node::gmail_node()
{

}


// Deconstructor
gmail_node::~gmail_node()
{

}


// Deletes LLL
void gmail_node::deletion_gmail(gmail_node * & head)
{
  if(head == NULL)
  {
    return;
  } 

  gmail_node * temp = head -> get_next();
  delete head;

  deletion_gmail(temp);
}



// Get next
gmail_node *& gmail_node::get_next()
{
 return next;
}



// Set next
void gmail_node::set_next(gmail_node * & temp)
{
  this -> next = temp;
}
	    


// Displays LLL
void gmail_node::display(gmail_node * & head_g)
{
  if(head_g == NULL)
   return ;

  if(head_g -> message_type == 1)
    cout << "\nMessage to " << head_g -> recipient << ":" << endl;
  
  if(head_g -> message_type == 2)
    cout << "\nMessage from " << head_g -> recipient << ":" << endl;

  cout << "\nSubject: " << head_g -> subject << endl;
  cout << endl << endl << head_g -> message << "\n\n\n\n\n\n\n" << endl;

  gmail_node * temp;
  temp = head_g -> get_next();

  display(temp);
  return; 
}

	  

// Removes All
void gmail_node::remove_all(gmail_node * & head_g)
{
  if(head_g == NULL)
  {
    return;
  }


  gmail_node * hold = head_g ->get_next();
  delete head_g;

  head_g = hold;

  remove_all(head_g);
}



// Removes one
void gmail_node::remove(gmail_node * & head_g,char name[])
{
  gmail_node * end = NULL;
 
  if(head_g == NULL)
  {
    cout << "\nMessage not found!" << endl;    
    return;
  }


  if(strcmp(head_g -> recipient, name) == 0)
  {
    cout << head_g -> recipient << endl;
    cout << name << endl;
    gmail_node * remove = head_g;
    head_g = head_g -> get_next();
    delete remove;
    return ;      
  } 


  gmail_node * forward = head_g -> get_next(); 
  
  if(forward == NULL)
    return;

  if(strcmp(forward -> recipient, name) == 0)
  {
    gmail_node * hold = forward -> get_next();

    if(hold == NULL) 
    {
      head_g -> set_next(end);
      delete forward;
      return;
    }

    head_g -> set_next(hold);
    delete forward;
    return;
  }

  gmail_node * temp = head_g -> get_next();
  remove(temp,name);

  return;
}

