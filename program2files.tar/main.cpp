#include"node_2.h"
// Channer Bok Program 2 main.cpp file
// This file helpg the user manage their different accounts and provides a menu
// to add, use, remove, or display all of their accounts


int main()
{
  cout << "\nWelcome to The Communicator program."
       << "\nThis program will allow you to create"
       << "\nMultiple different accounts across three"
       << "\ndifferent programs. You be able to send and"
       << "\nreceive messages from all of the applications"
       << "\nLets begin!" 
       << endl;  

  main_menu();

  cout << "\nThanks for using The Communicator program, have a great day!" << endl;
  return 0;
}



void main_menu()
{
  // Local Variables
  char temp[30];       // Holds account name
  char temp_user[30];  // Hold search name
  char temp_pw[30];    // Hold Password
  char temp_search[30];// Holds search name
  int selection;       // App selection
  int menu = 0;        // Main Menu Selection
  int create_flag;     // So they can't do anything but add a node first
  list manager;        // LLL of comm points manager


  // Main Menu
  while(menu != 6)
  {
    cout << "\nMain Menu:"
	 << "\nWould you like to add an account or user an existing one?"
	 << "\n1. Add"
	 << "\n2. Use"
	 << "\n3. See All Accounts"
	 << "\n4. Delete an account"
	 << "\n5. Delete all accounts"
	 << "\n6. Quit"
	 << endl;
    
    cin  >> menu;
    cin.ignore(100,'\n');


    // Add an account to the LLL
    if(menu == 1) 
    {
      cout << "\nWhat program would you like to add an account for?" << endl
           << "\n1. Messenger" 
           << "\n2. Gmail"
           << "\n3. Discord"
           << endl;

      cin >> selection;
      cin.ignore(100,'\n');
      create_flag = 1;   
      
      manager.Add_wrapper(selection,temp_user,temp_pw);
      cout << "\nAccount Added." << endl;
    }


    // Use an account
    if(menu == 2 && create_flag == 1)
    {
      cout << "What is the account name you would like to use?" << endl;
      cin.get(temp,30,'\n');
      cin.ignore(100,'\n');
      manager.Use(temp);
    }

    else if(menu  == 2 && create_flag == 0)
       cout << "\nNo accounts have been added yet" << endl;


    // Display all accounts
    if(menu == 3 && create_flag == 1)
    {
      manager.Wrapper_display(4);
    } 
   
    // Remove account 
    if(menu == 4 && create_flag == 1)
    {
      cout << "\nPlease enter the name of the account you wish to remove" << endl;
      cin.get(temp_search,30,'\n');
      cin.ignore(100,'\n');

      manager.Remove(temp_search,4);
    } 
    
    // Remove all accounts
    if(menu == 5 && create_flag == 1)
    {
      manager.Wrapper_Remove_All(4);
    } 

  }

  return ;

}

