// Channer Bok Program 3 class.h file
// This file houses the class interfaces for the base class as well as 
// the four derived classes. It holds the prototypes of all of the member
// functions as well as all the operator overloading functions both
// member and friend. It also houses 
// the function prototypes for the client that are utilized in
// main to simulate the monster battle.


#include<iostream>
#include<cctype>
#include<cstring>
using namespace std;



// Base Class
class monster
{
      public:
           monster();                                     // Constructor
	   ~monster();                                    // Deconstructor
	   monster(const monster & source, int modifier); // Copy Constructor

	   void add(int id);                              // Prompt For Input 
	   void remove();                                 // Deallocates Dynamic Memory
	   int find(char temp_name[], int & temp_id);     // Used for searching
	   int compare(char new_name[]);                  // Compares Data
	   void grab(char temp_name[], char temp_type[]); // Used for searching
	   void set_monster(const monster & new_monster); // Used for derived class operator overloading
	   void set_monster(const monster & new_monster, int modifier); // Used for derived class operator overloading with +

	   
	   void display() const;                                                 // Used for derived class << operator overloading
	   monster & operator += (const int strength_mod);                       // Plus equal operator
           monster & operator = (const monster & source);                        // Assignment operator
	   monster operator + (const int modifier);                              // Addition operator
	   friend int operator < (monster & object_one, monster & object_two);   // Less than operator

	   
	   int operator == (const monster & object)const;  // Equality Operator
	   int operator != (const monster & object)const;  // None-Equality operator



      protected:
           char * name;    // Monster Name
           char * color;   // Monster Color
	   char * attack;  // Monter Attack
	   int monster_id; // id for data structures
           int hp;         // Monster hitpoints
           int strength;   // Monster strength rating
           int defense;    // Monster defense rating
	   char * monster_type; // Type of monster
};




// Dragon-Type of monster
class dragon: public monster
{
      public:
	   dragon();                                       // Constructor
	   ~dragon();                                      // Deconstructor
	   dragon(const dragon & source);                  // Copy Const.
	   dragon(const dragon & new_dragon, int modifier);// Copy Funciton.
	   
	   void grab(char temp_name[], char temp_type[]);  // Copies Monster name and type 
	   void add(int id);                               // Input
	   int find(char temp_name[], int & temp_id);      // Used For searching
	   void remove();                                  // Deallocates Data
           
	   dragon & operator =(const dragon & object);     // Assignment
	   dragon & operator += (const int strength_mode); // Plus equals
	   dragon operator + (const int modifier) const;   // Addition
	 
	  
	   friend ostream & operator << (ostream & O, const dragon & object);  // Output

	   int operator == (const dragon & object) const;                // Equality
	   int operator == (const class vampire & object) const;         // Equality w/ vampire monster
	   int operator == (const class zombie & object) const;          // Equality w/ zombie monster
	   int operator == (const class werewolf & object) const;        // Equality w/ werewolf monster
	   int operator != (const dragon & object) const;                // None-Equaility
	   
   protected:
	   char * type;  // Type of dragon
};



// Vampire-Type of monster
class vampire: public monster
{
      public:
	   vampire();                                         // Constructor
	   ~vampire();                                        // Deconstructor
	   vampire(const vampire & source);                   // Copy Const.
	   vampire(const vampire & new_vampire, int modifier);// Copy Function

	   void add(int id);                                  // Input
	   void remove();                                     // Deallocates Data
	   void grab(char temp_name[], char temp_type[]);     // Copies data for searching
	   int find(char temp_name[], int & temp_id);         // Used for searching
           
	   vampire & operator =(const vampire & object);                        // Assignment
	   vampire & operator += (const int strength_mode);                     // Plus equals
	   vampire operator + (const int modifier)const;                        // Addition

	   friend vampire operator + (const vampire & OBJECT,const char name[]);// Addition
	   friend ostream & operator << (ostream & O,vampire & object);         // Output

	   int operator != (const vampire & object) const;                      // Non-Equality
	   int operator == (const vampire & object) const;                      // Equality
	   int operator == (const dragon & object) const;                       // Equality w/ dragon monster
	   int operator == (const class zombie & object) const;                 // Eqaulity w/ zombie monster
	   int operator == (const class werewolf & object) const;               // Equality w/ werewolf monster


      protected:
	   char * type;  // Vampire type
};




// Werewolf-Type of Monster
class werewolf: public monster
{
      public:
	   werewolf();                                           // Constructor
	   ~werewolf();                                          // Deconstructor 
	   werewolf(const werewolf & source);                    // Copy Const
	   werewolf(const werewolf & new_vampire, int modifier); // Copy Function

	   void add(int id);                                     // Input
	   void remove();                                        // Deallocates Data
	   
	   void grab(char temp_name[], char temp_type[]);        // Used for Searching
	   int find(char temp_name[], int & temp_id);            // Used for Searching
           
	   werewolf & operator =(const werewolf & object);                         // Assignment
	   werewolf & operator += (const int strength_mode);                  // Plus eqauls
	   werewolf operator + (const int modifier)const;                          // Addition

	   friend werewolf operator + (const werewolf & OBJECT,const char name[]); // Addition
	   friend ostream & operator << (ostream & O, werewolf & object);          // Output



	   int operator != (const werewolf & object) const;   // None-equality
	   int operator == (const werewolf & object) const;   // Equality
	   int operator == (const vampire & object) const;    // Eqaulity w/ vampire monster
	   int operator == (const dragon & object) const;     // Equality w/ dragon monster
	   int operator == (const class zombie & object) const;// Equality w/ zombie monster


      protected:
	   char * type; // Zombie type

};



// Zombie-Type of Monster
class zombie: public monster
{


      public:
	   zombie();                                        // Constructor
	   ~zombie();                                       // Deconstructor
	   zombie(const zombie & source);                   // Copy Const.
	   zombie(const zombie & new_zombie, int modifier); // Copy Function

	   void add(int id);                                // Input
	   void remove();                                   // Deallocates Data
	   
	   void grab(char temp_name[], char temp_type[]);   // Used for searching
	   int find(char temp_name[], int & temp_id);       // Used to copy data
           
	   zombie & operator =(const zombie & object);                         // Assignment
	   zombie & operator += (const int strength_mode);                     // Plus equals
	   zombie operator + (const int modifier)const;                        // Addition
	   
	   friend zombie operator + (const zombie & OBJECT,const char name[]); // Addition
	   friend ostream & operator << (ostream & O, zombie & object);        // Output

	   
	   int operator == (const zombie & object) const;   // Equality
	   int operator != (const zombie & object) const;   // Non-Equality
	   int operator == (const werewolf & object) const; // Equality w/ werewolf monster
	   int operator == (const vampire & object) const;  // Eqaulity w/ vampire monster
	   int operator == (const dragon & object) const;   // Equality w/ dragon monster


      protected:
	   char * type;  // Type of zombie


};



// Function Prototypes

// Main Menu Interface
void main_menu();

// Data Structure Interface
void data(class list & tree_object, class list & doubly_object);


// Edit Monster Attributes
void edit(dragon Dragons[],int dragon_count);
void edit(vampire Vampires[],int vampire_count);
void edit(werewolf Werewolves[],int werewolf_count);
void edit(zombie Zombies[],int zombie_count);


// Wrapper Functions to deallocate/delete monsters
void remove(dragon Dragons[],int dragon_count,class list & tree_object, class list & doubly_object);
void remove(vampire Vampires[],int vampire_count,class list & tree_object, class list & doubly_object);
void remove(werewolf Werewolves[],int werewolf_count, class list & tree_object,  class list  & doubly_object);
void remove(zombie Zombies[],int zombie_count, class list & tree_object, class list & doubly_object);


// Finds Selected Monster's information for fight simulation
int battle(dragon dragons[],int & index);
int battle(vampire vampires[],int & index);
int battle(zombie zombies[], int & index);
int battle(werewolf werewolves[], int & index);



// Used for the different combinations of monster battles


// Dragon Vs. Other Monster Fight Simulations
int fight(dragon dragons[],int first_index,int second_index);
int fight(dragon dragons[],int first_index,vampire vampires[],int second_index);
int fight(dragon dragons[],int first_index,werewolf werewolves[], int second_index);
int fight(dragon dragons[],int first_index,zombie zombies [], int second_index);


// Vampire Vs. Other Monster Fight Simulations
int fight(vampire vampires[],int first_index, int second_index);
int fight(vampire vampires[],int first_index, dragon dragons[],int second_index);
int fight(vampire vampires[],int first_index, werewolf werewolves[],int second_index);
int fight(vampire vampires[],int first_index, zombie zombies[],int second_index);


// Werewolf Vs. Other Monster Fight Simulations
int fight(werewolf werewolves[], int first_index, int second_index);
int fight(werewolf werewolves[], int first_index, dragon dragons[],int second_index);
int fight(werewolf werewolves[], int first_index, vampire vampires[],int second_index);
int fight(werewolf werewolves[], int first_index, zombie zombies[],int second_index);


// Zombie Vs. Other Monster Fight Simulations
int fight(zombie zombies[], int first_index, int second_index);
int fight(zombie zombies[], int first_index, dragon dragons[],int second_index);
int fight(zombie zombies[], int first_index, vampire vampires[],int second_index);
int fight(zombie zombies[], int first_index, werewolf werewolves [],int second_index);

