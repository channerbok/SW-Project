// Channer Bok fight functions .cpp file
// The Fight Functions send in two monsters to do battle
// All combinations of different Monsters are possible
// The fight simulations utilize operator overloading
// to determine the winner of the battle
// They are called from main.


#include"structure.h"


// Dragon Vs. Dragon Fight Sim
int fight(dragon dragons[],int first_index,int second_index)
{
  int result;
  int damage  = -5;

  cout << "Dragon Vs. Dragon" << endl;
  result = dragons[first_index] < dragons[second_index];

  if(dragons[first_index] == dragons[second_index])
  {
    cout << "\nThe Monsters Are equally Matched" << endl; 
    return 0;
  }
    
  if(result == 1)
  {
    cout << "The first monster Wins!" << endl;
    dragons[second_index] += damage; 
  }
    
  else
  {
    cout << "The second monster Wins!" << endl;
    dragons[first_index] += damage; 
  }

  cout << "\nAfter Battle Report" << endl << endl;
  cout << dragons[first_index] << endl;
  cout << dragons[second_index] << endl;
  return 0;
}
	


// Dragon Vs. Vampire Fight Sim
int fight(dragon dragons[],int first_index,vampire vampires[],int second_index)
{
  int result;
  int damage  = -5;

  cout << "Dragon vs. Vampire" << endl;
  result = dragons[first_index] < vampires[second_index];
    
  if(dragons[first_index] == vampires[second_index])
  {
    cout << "\nThe Monsters Are equally Matched" << endl; 
    return 0;
  }
  
  
  if(result == 1)
  {
    cout << "The Dragon Wins!" << endl;
    vampires[second_index] += damage; 
  }
    
  else
  {
    cout << "The Vampire Wins!" << endl;
    dragons[first_index] += damage; 
  }

  cout << "\nAfter Battle Report" << endl << endl;
  cout << dragons[first_index] << endl;
  cout << vampires[second_index] << endl;
  return 0;
}




// Dragon Vs. Werewolf Fight Sim
int fight(dragon dragons[],int first_index,werewolf werewolves[], int second_index)
{
  int result;
  int damage  = -5;
    
  cout << "Dragon vs. Werewolf" << endl;
  result = dragons[first_index] < werewolves[second_index];

  if(dragons[first_index] == werewolves[second_index])
  {
    cout << "\nThe Monsters Are equally Matched" << endl; 
    return 0;
  }

  if(result == 1)
  {
    cout << "The Dragon Wins!" << endl;
    werewolves[second_index] += damage; 
  }
    
  else
  {
    cout << "The Werewolf Wins!" << endl;
    dragons[first_index] += damage; 
  }

  cout << "\nAfter Battle Report" << endl << endl;
  cout << dragons[first_index] << endl;
  cout << werewolves[second_index] << endl;
  return 0;
}



// Dragon Vs. Zombie Fight Sim
int fight(dragon dragons[],int first_index,zombie zombies [], int second_index)
{
  int result;
  int damage  = -5;
    
  cout << "Dragon vs. Zombie" << endl;
  result = dragons[first_index] < zombies[second_index];

  
  if(dragons[first_index] == zombies[second_index])
  {
    cout << "\nThe Monsters Are equally Matched" << endl; 
    return 0;
  }


  if(result == 1)
  {
    cout << "The Dragon Wins!" << endl;
    zombies[second_index] += damage; 
  }
    
  else
  {
    cout << "The Zombie Wins!" << endl;
    dragons[first_index] += damage; 
  }

  cout << "\nAfter Battle Report" << endl << endl;
  cout << dragons[first_index] << endl;
  cout << zombies[second_index] << endl;
  return 0;
}



// Vampire vs. Vampire Fight Sim
int fight(vampire vampires[],int first_index, int second_index)
{
  int result;
  int damage  = -5;

    
  cout << "Vampire vs. Vampire" << endl;
  result = vampires[first_index] < vampires[second_index];

  if(vampires[first_index] == vampires[second_index])
  {
    cout << "\nThe Monsters Are equally Matched" << endl; 
    return 0;
  }


  if(result == 1)
  {
    cout << "The First Vampire Wins!" << endl;
    vampires[second_index] += damage; 
  }
    
  else
  {
    cout << "The Second Vampire Wins!" << endl;
    vampires[first_index] += damage; 
  }

  cout << "\nAfter Battle Report" << endl << endl;
  cout << vampires[first_index] << endl;
  cout << vampires[second_index] << endl;
  return 0;
}



// Vampire vs. Dragon Fight Sim
int fight(vampire vampires[],int first_index, dragon dragons[],int second_index)
{
  int result;
  int damage  = -5;
 
    
  cout << "Vampire vs. Dragon" << endl;
  result = vampires[first_index] < dragons[second_index];

  if(vampires[first_index] == dragons[second_index])
  {
    cout << "\nThe Monsters Are equally Matched" << endl; 
    return 0;
  }


  if(result == 1)
  {
    cout << "The Vampire Wins!" << endl;
    dragons[second_index] += damage; 
  }
    
  else
  {
    cout << "The Dragon Wins!" << endl;
    vampires[first_index] += damage; 
  }

  cout << "\nAfter Battle Report" << endl << endl;
  cout << vampires[first_index] << endl;
  cout << dragons[second_index] << endl;
  return 0;
}



// Vampire vs. Werewolf Fight Sim
int fight(vampire vampires[],int first_index, werewolf werewolves[],int second_index)
{
  int result;
  int damage  = -5;

    
  cout << "Vampire vs. Werewolf" << endl;
  result = vampires[first_index] < werewolves[second_index];

  if(vampires[first_index] == werewolves[second_index])
  {
    cout << "\nThe Monsters Are equally Matched" << endl; 
    return 0;
  }


  if(result == 1)
  {
    cout << "The Vampire Wins!" << endl;
    werewolves[second_index] += damage; 
  }
    
  else
  {
    cout << "The Werewolf Wins!" << endl;
    vampires[first_index] += damage; 
  }

  cout << "\nAfter Battle Report" << endl << endl;
  cout << vampires[first_index] << endl;
  cout << werewolves[second_index] << endl;
  return 0;
}




// Vampire vs. Zombie Fight Sim
int fight(vampire vampires[],int first_index, zombie zombies[],int second_index)
{
  int result;
  int damage  = -5;

    
  cout << "Vampire vs. Zombie" << endl;
  result = vampires[first_index] < zombies[second_index];

  if(vampires[first_index] == zombies[second_index])
  {
    cout << "\nThe Monsters Are equally Matched" << endl; 
    return 0;
  }


  if(result == 1)
  {
    cout << "The Vampire Wins!" << endl;
    zombies[second_index] += damage; 
  }
    
  else
  {
    cout << "The Zombie Wins!" << endl;
    vampires[first_index] += damage; 
  }

  cout << "\nAfter Battle Report" << endl << endl;
  cout << vampires[first_index] << endl;
  cout << zombies[second_index] << endl;
  return 0;
}



// Werewolf vs. Werewolf Fight Sim
int fight(werewolf werewolves[], int first_index, int second_index)
{
  int result;
  int damage  = -5;

    
  cout << "Werewolf vs. Werewolf" << endl;
  result = werewolves[first_index] < werewolves[second_index];
    
  if(werewolves[first_index] == werewolves[second_index])
  {
    cout << "\nThe Monsters Are equally Matched" << endl; 
    return 0;
  }

  if(result == 1)
  {
    cout << "The First Werewolf Wins!" << endl;
    werewolves[second_index] += damage; 
  }
    
  else
  {
    cout << "The Second Werewolf Wins!" << endl;
    werewolves[first_index] += damage; 
  }

  cout << "\nAfter Battle Report" << endl << endl;
  cout << werewolves[first_index] << endl;
  cout << werewolves[second_index] << endl;
  return 0;
}





// Werewolf vs. Dragon Fight Sim
int fight(werewolf werewolves[], int first_index, dragon dragons[],int second_index)
{
  int result;
  int damage  = -5;
    
  cout << "Werewolf vs. Dragon" << endl;
  result = werewolves[first_index] < dragons[second_index];

  if(werewolves[first_index] == dragons[second_index])
  {
    cout << "\nThe Monsters Are equally Matched" << endl; 
    return 0;
  }


  if(result == 1)
  {
    cout << "The Werewolf Wins!" << endl;
    dragons[second_index] += damage; 
  }
    
  else
  {
    cout << "The Dragon Wins!" << endl;
    werewolves[first_index] += damage; 
  }

  cout << "\nAfter Battle Report" << endl << endl;
  cout << werewolves[first_index] << endl;
  cout << dragons[second_index] << endl;
  return 0;
}





// Werewolf vs. Vampires Fight Sim
int fight(werewolf werewolves[], int first_index, vampire vampires[],int second_index)
{
  int result;
  int damage  = -5;

  
    
  cout << "Werewolf vs. Vampire" << endl;
  result = werewolves[first_index] < vampires[second_index];

  if(werewolves[first_index] == vampires[second_index])
  {
    cout << "\nThe Monsters Are equally Matched" << endl; 
    return 0;
  }


  if(result == 1)
  {
    cout << "The Werewolf Wins!" << endl;
    vampires[second_index] += damage; 
  }
    
  else
  {
    cout << "The Vampire Wins!" << endl;
    werewolves[first_index] += damage; 
  }

  cout << "\nAfter Battle Report" << endl << endl;
  cout << werewolves[first_index] << endl;
  cout << vampires[second_index] << endl;
  return 0;
}




// Werewolf vs. Zombie Fight Sim
int fight(werewolf werewolves[], int first_index, zombie zombies[],int second_index)
{
  int result;
  int damage  = -5;

    
  cout << "Werewolf vs. Zombie" << endl;
  result = werewolves[first_index] < zombies[second_index];

  if(werewolves[first_index] == zombies[second_index])
  {
    cout << "\nThe Monsters Are equally Matched" << endl; 
    return 0;
  }


  if(result == 1)
  {
    cout << "The Werewolf Wins!" << endl;
    zombies[second_index] += damage; 
  }
    
  else
  {
    cout << "The Zombie Wins!" << endl;
    werewolves[first_index] += damage; 
  }

  cout << "\nAfter Battle Report" << endl << endl;
  cout << werewolves[first_index] << endl;
  cout << zombies[second_index] << endl;
  return 0;
}



// Zombie vs. Zombie Fight Sim
int fight(zombie zombies[], int first_index, int second_index)
{
  int result;
  int damage  = -5;

    
  cout << "Zombie vs. Zombie" << endl;
  result = zombies[first_index] < zombies[second_index];

  if(zombies[first_index] == zombies[second_index])
  {
    cout << "\nThe Monsters Are equally Matched" << endl; 
    return 0;
  }


  if(result == 1)
  {
    cout << "The First Zombie Wins!" << endl;
    zombies[second_index] += damage; 
  }
    
  else
  {
    cout << "The Second Zombie Wins!" << endl;
    zombies[first_index] += damage; 
  }

  cout << "\nAfter Battle Report" << endl << endl;
  cout << zombies[first_index] << endl;
  cout << zombies[second_index] << endl;
  return 0;
}




// Zombie vs. Dragon Fight Sim
int fight(zombie zombies[], int first_index, dragon dragons[],int second_index)
{
  int result;
  int damage  = -5;

    
  cout << "Zombie vs. Dragon" << endl;
  result = zombies[first_index] < dragons[second_index];

  if(zombies[first_index] == dragons[second_index])
  {
    cout << "\nThe Monsters Are equally Matched" << endl; 
    return 0;
  }


  if(result == 1)
  {
    cout << "The Zombie Wins!" << endl;
    dragons[second_index] += damage; 
  }
    
  else
  {
    cout << "The Dragon Wins!" << endl;
    zombies[first_index] += damage; 
  }

  cout << "\nAfter Battle Report" << endl << endl;
  cout << zombies[first_index] << endl;
  cout << dragons[second_index] << endl;
  return 0;
}




// Zombie vs. Vampire Fight Sim
int fight(zombie zombies[], int first_index, vampire vampires[],int second_index)
{
  int result;
  int damage  = -5;

    
  cout << "Zombie vs. Vampire" << endl;
  result = zombies[first_index] < vampires[second_index];

  if(zombies[first_index] == vampires[second_index])
  {
    cout << "\nThe Monsters Are equally Matched" << endl; 
    return 0;
  }



  if(result == 1)
  {
    cout << "The Zombie Wins!" << endl;
    vampires[second_index] += damage; 
  }
   
  else
  {
    cout << "The Vampire Wins!" << endl;
    vampires[first_index] += damage; 
  }

  cout << "\nAfter Battle Report" << endl << endl;
  cout << zombies[first_index] << endl;
  cout << vampires[second_index] << endl;
  return 0;
}




// Zombie vs. Werewolf Fight Sim
int fight(zombie zombies[], int first_index, werewolf werewolves [],int second_index)
{
  int result;
  int damage  = -5;

    
  cout << "Zombie vs. Werewolf" << endl;
  result = zombies[first_index] < werewolves[second_index];

  if(zombies[first_index] == werewolves[second_index])
  {
    cout << "\nThe Monsters Are equally Matched" << endl; 
    return 0;
  }


  if(result == 1)
  {
    cout << "The Zombie Wins!" << endl;
    werewolves[second_index] += damage; 
  }
    
  else
  {
    cout << "The Werewolf Wins!" << endl;
    werewolves[first_index] += damage; 
  }

  cout << "\nAfter Battle Report" << endl << endl;
  cout << zombies[first_index] << endl;
  cout << werewolves[second_index] << endl;
  return 0;
}

