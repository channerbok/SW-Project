// Channer Bok Program main.cpp file
// This file is setup in the following manner;
//
//
// 1. Four Arrays of derived class objects are created an housed within this file.
//    All operations on the monster class are chosen by the user within the menu
//    interface. After the correct object has been found, the object calls its own
//    member functions to create and manage its data.
//
// 2. As monsters are added, the list class takes the data and begins to create the 
//    BST and DLL and populate it with the data from the monster objects. The BST
//    houses the name and type of monster and the array of DLLs houses the attributes
//    of the monsters. Option number 6 of the menu allows the user to view the
//    data within the data structures. When a object is removed from the user's monster 
//    collection, it is also removed from the data structure. If the user decides to choose 
//    option number 7, then all of the monster objects will be deleted as well as all of
//    the data in the data structures.
//
//
//
// 3. The monster fight simulation will have the user choose two monsters of any type
//    and will call the correct fight function for that combination. There are many 
//    different fight functions to facilitate the different possible combinations of the monsters
//    and all the user to choose any monster to fight another monster.
//
//
// 4. When the program has been terminated, all of the monsters in the array of objects are destroyed
//    as well as all of the data within the data structures.


#include"structure.h"



// Main
int main()
{
  cout << "\nWelcome to Monster Battle" 
       << "\nThis program will allow to create"
       << "\nyour own type of monster and customize it."
       << "\nYou will then be able to have a monster fight between"
       << "\nany other availible monster. Lets begin!" 
       << endl;
  main_menu();

  cout << "\nThank you for playing monster battle! \nGoodbye." << endl;

  return 1;
}



// Menu interface for the user
void main_menu()
{
  // Vavriables
  char temp_name[30];    // Holds various temp names
  char temp_type[30];    // Holds Monster type
  int monster_type;      // User selection for monster type
  int menu;              // Menu choice


  // Array of objects for each monster type
  dragon Dragons[20];     // Dragons objects
  vampire Vampires[20];   // Vampire Objects
  werewolf Werewolves[20];// Werewolf Objects
  zombie Zombies[20];     // Zombie objects


  // Holds the amount of monsters added for the type of monster
  int dragon_count = 0;
  int vampire_count = 0;
  int werewolf_count = 0;
  int zombie_count = 0;


  // List objects to hold the data in the data structures
  list tree_object;  // BST
  list doubly_object;// DLL


  while(menu != 7 && menu != 8) 
  {
    cout << "\n\nMain Menu:" 
	 << "\n1. Add a monster to your collection"
	 << "\n2. Change a monster's stats"
	 << "\n3. Display all Monsters"
	 << "\n4. Remove a monster"
	 << "\n5. Start Monster Battle"
	 << "\n6. View Monster Cloud"
	 << "\n7. Delete All Data and Quit"
	 << "\n8. Quit "
	 << endl;
    cin >> menu;
    cin.ignore(100,'\n');
    
	 
    // Add a monster 
    if(menu == 1)
    {
      cout << "\nPlease choose a monster to add" 
           << "\n1. Dragon"
           << "\n2. Vampire"
           << "\n3. Werewolf"
           << "\n4. Zombie"
           << endl;
      cin >> monster_type;
      cin.ignore(100,'\n');

      // Adds a dragon to BST, DLL, and creates new dragon object
      if(monster_type == 1)
      {
        Dragons[dragon_count].add(dragon_count);
        Dragons[dragon_count].grab(temp_name,temp_type);
        tree_object.Add_Monster(temp_name,temp_type,dragon_count,monster_type);
	doubly_object.Add_abilities(monster_type,dragon_count);
        ++dragon_count;
      }

     
      // Adds a vampire to BST, DLL, and creates new vampire object
      if(monster_type == 2)
      {
        Vampires[vampire_count].add(vampire_count);
        Vampires[vampire_count].grab(temp_name,temp_type);
        tree_object.Add_Monster(temp_name,temp_type,vampire_count,monster_type);
	doubly_object.Add_abilities(monster_type,vampire_count);
	++vampire_count;
      }

      
      // Adds a werewolf to BST, DLL, and creates new werewolf object
      if(monster_type == 3)
      {
        Werewolves[werewolf_count].add(werewolf_count);
        Werewolves[werewolf_count].grab(temp_name,temp_type);
        tree_object.Add_Monster(temp_name,temp_type,werewolf_count,monster_type);
	doubly_object.Add_abilities(monster_type,werewolf_count);
	++werewolf_count;
      }


      // Adds a zombie to BST, DLL, and creates new zombie object
      if(monster_type == 4)
      {
        Zombies[zombie_count].add(zombie_count);
        Zombies[zombie_count].grab(temp_name,temp_type);
        tree_object.Add_Monster(temp_name,temp_type,zombie_count,monster_type);
	
        doubly_object.Add_abilities(monster_type,zombie_count);
	++zombie_count;
      }
    }
   

    // Alters Monsters Stats 
    if(menu == 2)
    {
      cout << "\nPlease enter the type of monster" 
           << "\n1. Dragon"
           << "\n2. Vampire"
           << "\n3. Werewolf"
           << "\n4. Zombie"
           << endl;
      
      cin >> monster_type;
      cin.ignore(100,'\n');

      // Dragon option
      if(monster_type == 1)
      {
         edit(Dragons,dragon_count);
      }

     
      // Vampire Choice 
      if(monster_type == 2)
      {
        edit(Vampires,vampire_count);
      }
     

      // Werewolf option 
      if(monster_type == 3)
      {
        edit(Werewolves,werewolf_count);
      }
     

      // Zombie option 
      if(monster_type == 4)
      {
        edit(Zombies,zombie_count);
      }
    }
  

    // Displays all objects with operator overloadiong the << operator 
    if(menu == 3)
    {
      for(int i=0;i<dragon_count;++i)
      {
        cout << Dragons[i] << endl;
      }
      for(int i=0;i<vampire_count;++i)
      {
        cout << Vampires[i] << endl;
      }

      for(int i=0;i<werewolf_count;++i)
      {
        cout << Werewolves[i] << endl;
      }

      for(int i=0;i<zombie_count;++i)
      {
        cout << Zombies[i] << endl;
      }

    }

    // Remove a monster
    if(menu == 4)
    {
      cout << "\nPlease enter the type of monster" 
           << "\n1. Dragon"
           << "\n2. Vampire"
           << "\n3. Werewolf"
           << "\n4. Zombie"
           << endl;

      cin >> monster_type;
      cin.ignore(100,'\n');

      // Calls function to remove dragon 
      if(monster_type == 1)
      {
        remove(Dragons,dragon_count,tree_object,doubly_object); 
      }
      
      // Calls function to remove vampire
      if(monster_type == 2)
      {
        remove(Vampires,vampire_count,tree_object,doubly_object); 
      }
      
      // Calls function to remove werewolf
      if(monster_type == 3)
      {
        remove(Werewolves,werewolf_count,tree_object,doubly_object); 
      }
      
      // Calls function to remove zombie 
      if(monster_type == 4)
      {
        remove(Zombies,zombie_count,tree_object,doubly_object); 
      }
    
    }
   
    
    // Initiates Monster Battle 
    if(menu == 5)
    {
      // Variables
      int first = 1;       // First monster choice
      int second = 2;      // Second monster choice
      int first_index; // Index of first monster
      int second_index;// Index of second monster
      int flag_one = 0;// Flag
      int flag_two = 0;// Flag


      // Prompts user for first monster
      while(flag_one != 1)
      {
        cout << "\nPlease choose the first monster for battle" 
             << "\n1. Dragon"
             << "\n2. Vampire"
             << "\n3. Werewolf"
             << "\n4. Zombie"
             << endl;

        cin >> first;
        cin.ignore(100,'\n');

        // These obtain the index of the chosen monster
        if(first == 1)
        {
          first_index = battle(Dragons,dragon_count);
        }

        if(first == 2)
        {
          first_index = battle(Vampires,vampire_count);
        }
     
        if(first == 3)
        {
          first_index = battle(Werewolves,werewolf_count);
        }
      
        if(first == 4)
        {
          first_index = battle(Zombies,zombie_count);
        }

	if(first_index != 20 && first > 0 && first < 5)
          flag_one = 1; 
	
	if(first_index == 20)
          cout << "\nMonster not found. Please try again" << endl;
      }
    

      // Obtains second monster for battle 
      while(flag_two != 1)
      {
        cout << "\nPlease choose the second monster for battle" 
             << "\n1. Dragon"
             << "\n2. Vampire"
             << "\n3. Werewolf"
             << "\n4. Zombie"
             << endl;
        cin >> second;
        cin.ignore(100,'\n');
     

        // These obtain the index of the chosen monster
        if(second == 1)
        {
          second_index = battle(Dragons,dragon_count);
        }

        if(second == 2)
        {
          second_index = battle(Vampires,vampire_count);
        }
     
        if(second == 3)
        {
          second_index = battle(Werewolves,werewolf_count);
        }
      
        if(second == 4)
        {
          second_index = battle(Zombies,zombie_count);
        }
	
	if(second_index != 20 && second > 0 && second < 5)
          flag_two = 1; 
	
	if(second_index == 20)
          cout << "\nMonster not found. Please try again" << endl;
      }

     
      cout << "\n\nCommencing Battle" << endl << endl << endl;
     
      // Dragons Vs. Other monster 
      if(first == 1)
      {
	if(second == 1)
        fight(Dragons,first_index,second_index);

	if(second == 2)
	  fight(Dragons,first_index,Vampires,second_index);

	if(second == 3)
	  fight(Dragons,first_index,Werewolves,second_index);
	
	if(second == 4)
	  fight(Dragons,first_index,Zombies,second_index);
      }


      // Vampire vs. Other Monster
      if(first == 2)
      {
	if(second == 2)
        fight(Vampires,first_index,second_index);

	if(second == 1)
	  fight(Vampires,first_index,Dragons,second_index);

	if(second == 3)
	  fight(Vampires,first_index,Werewolves,second_index);
	
	if(second == 4)
	  fight(Vampires,first_index,Zombies,second_index);
      }


      // Werewolf vs. Other Monster
      if(first == 3)
      {
	if(second == 3)
        fight(Werewolves,first_index,second_index);

	if(second == 1)
	  fight(Werewolves,first_index,Dragons,second_index);

	if(second == 2)
	  fight(Werewolves,first_index,Vampires,second_index);
	
	if(second == 4)
	  fight(Werewolves,first_index,Zombies,second_index);
      }


      // Zombie Vs. Other Monster
      if(first == 4)
      {
	if(second == 4)
        fight(Zombies,first_index,second_index);

	if(second == 1)
	  fight(Zombies,first_index,Dragons,second_index);

	if(second == 2)
	  fight(Zombies,first_index,Vampires,second_index);
	
	if(second == 3)
	  fight(Zombies,first_index,Werewolves,second_index);
      }
    }


    // Deletes All monsters
    if(menu == 7)
    {
      for(int i=0;i<dragon_count;i++)
      {
        Dragons[i].remove();
      }
    
      for(int i=0;i<vampire_count;i++)
      {
        Vampires[i].remove();
      }
     
      for(int i=0;i<werewolf_count;i++)
      {
        Werewolves[i].remove();
      }
      
      for(int i=0;i<zombie_count;i++)
      {
        Zombies[i].remove();
      }

      tree_object.Delete();
      doubly_object.remove_all_wrap_ability();
      dragon_count = 0;
      vampire_count = 0;
      werewolf_count = 0;
      zombie_count = 0;
    }

    // Calls function to go to separate menu that browses the data structure
    if(menu == 6)
      data(tree_object,doubly_object);
  }
}


// Used to Display Data inside of the Data Structures AKA the saved files
void data(class list & tree_object, class list & doubly_object)
{
  // Menu choice
  int menu;


  while(menu != 5)
  {
    cout << "\n\nCloud Menu:" 
         << "\n1. Display All Monsters in Saved Files"
         << "\n2. Display All Monster Abilities in Saved Files"
         << "\n3. Display One Monsters in Saved Files"
         << "\n4. Display One Monster Ability in Saved Files"
	 << "\n5. Return to Main Menu"
         << endl;

    cin >> menu;
    cin.ignore(100,'\n');

    // Displays BST
    if(menu == 1)
      tree_object.Display_Monster(); 

    // Displays DLL
    if(menu == 2)
      doubly_object.Display_Abilities();


    // Displays one monster in BST
    if(menu == 3)
      tree_object.Display_One(); 
 
    // Displays one ability in DLL 
    if(menu == 4)
      doubly_object.Display_One_DLL();
    
    if(menu == 5)
      cout << "\n**Returning to Main Menu" << endl;
  }
}



// The battle functions return the index of the chosen monster
// So the fight sim uses the correct monster
   

// Dragon Index Finder
int battle(dragon dragons[],int & index)
{
   char temp_name[30];
   int id;

   cout << "\nPlease enter the monster name" << endl;
   cin.get(temp_name,30,'\n');
      
      
   for(int i=0;i<index;++i)
   {
     int result = dragons[i].find(temp_name,id);
	  
     if(result == 1)
     {
       return i;
       i = 10;
     }
   }

   return 20;
}




// Vampire Index Finder
int battle(vampire vampires[],int & index)
{  
   char temp_name[30];
   int id;

   cout << "\nPlease enter the monster name" << endl;
   cin.get(temp_name,30,'\n');
      
   for(int i=0;i<index;++i)
   {
     int result = vampires[i].find(temp_name,id);
	  
     if(result == 1)
     {
       return i;
       i = 10;
     }
   }

   return 20;
}





// Zombie Index Finder
int battle(zombie zombies[], int & index)
{
   char temp_name[30];
   int id;

   cout << "\nPlease enter the monster name" << endl;
   cin.get(temp_name,30,'\n');
      
      
   for(int i=0;i<index;++i)
   {
     int result = zombies[i].find(temp_name,id);
	  
     if(result == 1)
     {
       return i;
       i = 10;
     }
   }
   
   return 20;
}
      



// Werewolf Index Finder
int battle(werewolf werewolves[], int & index)
{
   char temp_name[30];
   int id;

   cout << "\nPlease enter the monster name" << endl;
   cin.get(temp_name,30,'\n');
      
      
   for(int i=0;i<index;++i)
   {
     int result = werewolves[i].find(temp_name,id);
	  
     if(result == 1)
     {
       return i;
       i = 10;
     }
   }
   
   return 20;
}



// The edit functions allow the user to change the stats of the monster
// Operator overloading is used to change the stats of the monster
// The functions search through the array of objects to locate the
// correct monster to edit


// Change Dragon Data
void edit(dragon Dragons[],int dragon_count)
{
  int id;
  int stat;
  int choice;
  int result;
  char temp_name[30];

  cout << "\nPlease enter the monster name" << endl;
  cin.get(temp_name,30,'\n');
    
  for(int i=0;i<dragon_count;++i)
  {
    result = Dragons[i].find(temp_name,id);
   	  
    if(result == 1)
    {
      cout << "\n**Monster Found**" << endl;
      cout << Dragons[i] << endl;
      cout << "\nYou can alter the folowing monster stats" 
           << "\n1.Hitpoints"
           << "\n2.Strength & Defense Ratings"
           << endl;
      cin >> choice;
      cin.ignore(100,'\n'); 

      cout << "\nPlease enter the value you wish to add to those stats" 
           << "\nEnter a positive to add it or negative value to subtract it"
           << "\nThe value will be added/subtracted from the selected stat."
	   << "\nPlease enter now: " 
	   << endl;

      cin >> stat; 
      cin.ignore(100,'\n'); 

      if(choice == 1)
      {
        Dragons[i] += stat;
      }

      if(choice == 2)
      {
        Dragons[i] = Dragons[i] + stat;
      }
            
      cout << "\n**Monster Stats altered by " << stat << "**" << endl;
      cout << Dragons[i] << endl;
      i = 100;
    } 
  }
   
   if(result != 1)
     cout << "Monster Not Found" << endl;
}




// Change Vampire Data
void edit(vampire Vampires[],int vampire_count)
{
  int stat;
  int choice;
  int id;
  int result;
  char temp_name[30];
  
  cout << "\nPlease enter the monster name" << endl;
  cin.get(temp_name,30,'\n');

  for(int i=0;i<vampire_count;++i)
  {
    result = Vampires[i].find(temp_name,id);
	  
    if(result == 1)
    {
      cout << "\n**Monster Found**" << endl;
      cout << Vampires[i] << endl;
      cout << "\nYou can alter the folowing monster stats" 
           << "\n1.Hitpoints"
           << "\n2.Strength & Defense Ratings"
           << endl;
      cin >> choice;
      cin.ignore(100,'\n'); 

      cout << "\nPlease enter the value you wish to add to those stats" 
           << "\nEnter a positive to add it or negative value to subtract it"
  	   << "\nThe value will be added/subtracted from the selected stat."
	   << "\nPlease enter now: " 
           << endl;

      cin >> stat; 
      cin.ignore(100,'\n'); 

      if(choice == 1)
      {
	Vampires[i] += stat;
      }

      if(choice == 2)
      {
        Vampires[i] = Vampires[i] + stat;
      }
          
      cout << "\n**Monster Stats altered by " << stat << "**" << endl;
      cout << Vampires[i] << endl;
      i = 100;
    }
  }

  if(result != 1)
    cout << "Monster Not Found" << endl;
}



// Change werewolf data
void edit(werewolf Werewolves[],int werewolf_count)
{
  int stat;
  int choice;
  int id;
  int result;
  char temp_name[30];
  
  cout << "\nPlease enter the monster name" << endl;
  cin.get(temp_name,30,'\n');

  for(int i=0;i<werewolf_count;++i)
  {
    result = Werewolves[i].find(temp_name,id);
	  
    if(result == 1)
    {
      cout << "\n**Monster Found**" << endl;
      cout << Werewolves[i] << endl;
      cout << "\nYou can alter the folowing monster stats" 
           << "\n1.Hitpoints"
           << "\n2.Strength & Defense Ratings"
           << endl;
      cin >> choice;
      cin.ignore(100,'\n'); 

      cout << "\nPlease enter the value you wish to add to those stats" 
           << "\nEnter a positive to add it or negative value to subtract it"
  	   << "\nThe value will be added/subtracted from the selected stat."
	   << "\nPlease enter now: " 
           << endl;

      cin >> stat; 
      cin.ignore(100,'\n'); 

      if(choice == 1)
      {
	Werewolves[i] += stat;
      }

      if(choice == 2)
      {
        Werewolves[i] = Werewolves[i] + stat;
      }

          
      cout << "\n**Monster Stats altered by " << stat << "**" << endl;
      cout << Werewolves[i] << endl;
      i = 100;
    }
  }
    
  if(result != 1)
    cout << "Monster Not Found" << endl;

}



// Change Zombie data
void edit(zombie Zombies[],int zombie_count)
{
  int stat;
  int choice;
  int id;
  int result;
  char temp_name[30];
 
  cout << "\nPlease enter the monster name" << endl;
  cin.get(temp_name,30,'\n');

  for(int i=0;i<zombie_count;++i)
  {
    result = Zombies[i].find(temp_name,id);
	  
    if(result == 1)
    {
      cout << "\n**Monster Found**" << endl;
      cout << Zombies[i] << endl;
      cout << "\nYou can alter the folowing monster stats" 
           << "\n1.Hitpoints"
           << "\n2.Strength & Defense Ratings"
           << endl;
      cin >> choice;
      cin.ignore(100,'\n'); 

      cout << "\nPlease enter the value you wish to add to those stats" 
           << "\nEnter a positive to add it or negative value to subtract it"
  	   << "\nThe value will be added/subtracted from the selected stat."
	   << "\nPlease enter now: " 
           << endl;

      cin >> stat; 
      cin.ignore(100,'\n'); 

      if(choice == 1)
      {
	Zombies[i] += stat;
      }

      if(choice == 2)
      {
	Zombies[i] = Zombies[i] + stat;
      }

          
      cout << "\n**Monster Stats altered by " << stat << "**" << endl;
      cout << Zombies[i] << endl;
      i = 100;
    }
    
  }
 
  if(result != 1)
    cout << "Monster Not Found" << endl;
}


// The remove functions locate the correct monster object for the user
// and then calls derived class function to delete the object




// Deletes a dragon monster
void remove(dragon Dragons[],int dragon_count,list & tree_object, list & doubly_object)
{
  int id;
  int result;
  int flag = 0;
  int monster_type = 1;
  char temp_name[30];

  cout << "\nPlease enter the monster name" << endl;
  cin.get(temp_name,30,'\n');
      
  for(int i=0;i<dragon_count;++i)
  {
    result = Dragons[i].find(temp_name,id);
    if(result == 1)
    { 
      flag = 1;
      tree_object.remove_monster_wrapper(temp_name,id);
      doubly_object.remove_ability(monster_type,id);
      Dragons[i].remove();
      cout << "Dragon Removed" << endl;
      i = 100;
    }
  }
  
  if(flag != 1)
    cout << "Monster Not Found" << endl;

}



// Deletes a werewolf monster
void remove(werewolf Werewolves[],int werewolf_count, list & tree_object, list  & doubly_object)
{
  int id;
  int result;
  int flag = 0;
  int monster_type = 2;
  char temp_name[30];

  cout << "\nPlease enter the monster name" << endl;
  cin.get(temp_name,30,'\n');
      
  for(int i=0;i<werewolf_count;++i)
  {
    result = Werewolves[i].find(temp_name,id);
      
    if(result == 1)
    { 
      flag = 1;
      tree_object.remove_monster_wrapper(temp_name,id);
      doubly_object.remove_ability(monster_type,id);
      Werewolves[i].remove();
      cout << "Werewolf Removed" << endl;
      i = 100;
    }
  }
  
  if(flag != 1)
    cout << "Monster Not Found" << endl;

}




// Deletes a vampire monster
void remove(vampire Vampires[],int vampire_count,list & tree_object, list & doubly_object)
{
  int id;
  int result;
  int flag = 0;
  int monster_type = 3;
  char temp_name[30];

  cout << "\nPlease enter the monster name" << endl;
  cin.get(temp_name,30,'\n');
      
  for(int i=0;i<vampire_count;++i)
  {
    result = Vampires[i].find(temp_name,id);
      
    if(result == 1)
    { 
      flag = 1;
      tree_object.remove_monster_wrapper(temp_name,id);
      doubly_object.remove_ability(monster_type,id);
      Vampires[i].remove();
      cout << "Vampire Removed" << endl;
      i = 100;
    }
  }
  
  if(flag != 1)
    cout << "Monster Not Found" << endl;

}




// Deletes a zombie monster
void remove(zombie Zombies[],int zombie_count, list & tree_object, list & doubly_object)
{
  int id = 0;
  int result;
  int flag = 0;
  int monster_type = 4;
  char temp_name[30];

  cout << "\nPlease enter the monster name" << endl;
  cin.get(temp_name,30,'\n');
      
  for(int i=0;i<zombie_count;++i)
  {
    result = Zombies[i].find(temp_name,id);
      
    if(result == 1)
    { 
      flag = 1;
      tree_object.remove_monster_wrapper(temp_name,id);
      doubly_object.remove_ability(monster_type,id);
      Zombies[i].remove();
      cout << "Zombie Removed" << endl;
      i = 100;
    }
  }
  
  if(flag != 1)
     cout << "Monster Not Found" << endl;
}

