// Channer Bok Program 3 data structure .cpp file
// This file implements the the data structures for the assignment,
// a BST as well as a array of DLL. The file implements the node classes
// as well as the list class that manages them.

#include"structure.h"
	  
	  
//**********************
// BST Node Class Implementation
//**********************



// Constructor
bst_node::bst_node()
{
  //pointer = NULL;
  left = NULL;
  right = NULL; 
}


// Deconstructor
bst_node::~bst_node()
{
}



// Get Left Pointer
bst_node * & bst_node::get_left()
{
  return left;
}




// Get Right Pointer
bst_node * & bst_node::get_right()
{
  return right;
}



// Set left pointer
void bst_node::set_left(bst_node * & new_left)
{
  this -> left = new_left;
}



// Set right pointer
void bst_node::set_right(bst_node * & new_right)
{
  this -> right = new_right;
}
	



// Copies Data from Monster added into the BST Node
void bst_node::read(char new_name[], char new_type[], int id, int monster_type)
{
  char temp[7] = "Dragon";
  char temp_v[8] = "Vampire";
  char temp_w[9] = "Werewolf";
  char temp_z[7] = "Zombie";
    
  name = new char[strlen(new_name) + 1]; 
  strcpy(name,new_name);

  monster_id = id;

  if(monster_type == 1)
  {
    type = new char[7]; 
    strcpy(type,temp);
  }

  if(monster_type == 2)
  {
    type = new char[8]; 
    strcpy(type,temp_v);
  }
 
  if(monster_type == 3)
  {
    type = new char[9]; 
    strcpy(type,temp_w);
  }
  
  if(monster_type == 4)
  {
    type = new char[7];
    strcpy(type,temp_z);
  }

  return;
}



// Used to compare values for Binary Search
int bst_node::compare(bst_node * & root, char new_name[])
{
  int result = 1;
  if(strcmp(new_name, root -> name) < 0)
    result = 0; 

  if(strcmp(new_name, root -> name) == 0)
    result = 3; 

  return result;
}



// Copies data from one node into another
// Used for removal
void bst_node::copy(bst_node * & copy)
{
  strcpy(name,copy -> name);
  strcpy(type,copy -> type);
  monster_id = copy -> monster_id;
  return;
}



// Displays Contents of node
void bst_node::display()
{
  cout << name << endl;
  cout << type << endl;
}


// Deletes Node
void bst_node::remove()
{
  delete [] name;
  name = NULL;

  delete [] type;
  type = NULL; 
}

	  



//**********************
// List Class Implementation
//**********************



// BST Implementation for List Class

// Constructor
list::list()
{
  array_size  = 4;
  table = new node * [array_size];

  for(int i=0;i<array_size;++i)
  {
    table[i] = NULL;
  }

  root = NULL;

}


// Destructor-Calls recursive function to delete all nodes in the BST
list::~list()
{
  Delete();
  remove_all_wrap_ability();

  delete [] table;
  delete root;
}


// Wrapper for adding a node to the BST
void list::Add_Monster(char new_name[], char new_type[], int id, int monster_type)
{
  add(root,new_name,new_type,id, monster_type);
}



// Creates a new node in the BST
void list::add(bst_node * & root, char new_name [], char new_type[], int id, int monster_type)
{
  if(root == NULL)
  {
    root  = new bst_node;
    root -> read(new_name, new_type, id, monster_type);
    bst_node * end = NULL;
    root -> set_left(end);
    root -> set_right(end);
    return; 
  } 


  int result = root -> compare(root,new_name);

  if(result == 1 || result == 3)
  {
    add(root->get_right(),new_name,new_type,id,monster_type);
    return;
  }

  else
  {
    add(root->get_left(),new_name,new_type,id, monster_type);
    return;
  }
  
  return;

}

	  
	 
// Wrapper Function to remove node from BST
void list::remove_monster_wrapper(char temp_name[], int id)
{
  remove_monster(root,temp_name,id);
}



// Traverses BST to find the matching node and removes is
// and adjusts the BST accordingly
void list::remove_monster(bst_node * & root, char temp_name[], int id)
{
  if(root == NULL)
   return;


  int result = root -> compare(root,temp_name);

  if(result == 1)
  {
    remove_monster(root->get_right(),temp_name,id);
    return;
  }

  else if(result == 0)
  {
    remove_monster(root->get_left(),temp_name,id);
    return;
  }

  else if(result == 3) 
  {
    bst_node * & left = root -> get_left();
    bst_node * & right = root -> get_right();
    
    // Match on a leaf    
    if(left == NULL && right == NULL)
    {
      root -> remove();
      delete root;
      root = NULL;      
      return;
    }

    // Match has only one child and its on the left
    if(left != NULL && right == NULL)
    {
      bst_node * temp = root;
      root  = left;
      temp -> remove();
      delete temp;
      return;
    }

    // Match has only one child and its on the right
    else if(left == NULL && right != NULL)
    {
      bst_node * temp = root;
      root = right;
      temp -> remove();
      delete temp;
      return;
    }

    // Match has two children
    if(left != NULL && right != NULL)
    {
      bst_node * current = root;
      bst_node * previous = current;
      current = current -> get_right();

      // The matches right child has a NULL left pointer
      // The right child is the IOS 
      if(current -> get_left() == NULL)
      {
	bst_node *  & temp = current -> get_right();
	root -> copy(current);
        current -> remove();
        delete current;
        root -> set_right(temp);
        return;
      }

      // Traverse through Child to find IOS.
      // Replace the Node with the IOS
      else if(current -> get_left() != NULL && current -> get_right() != NULL)
      {
        while(current -> get_left() != NULL)
	{
          previous = current;
	  current = current -> get_left(); 
	}

	bst_node *& hold = current -> get_right();
	root -> copy(current);
	current -> remove();
	delete current;
	previous -> set_left(hold);
	return;
      }
    }
 
    return;
  }
  
  return;
}








// Wrapper Function to display BST
void list::Display_Monster()
{
  display(root);
}


// Recursive Function to display all data in the BST in order
void list::display(bst_node * root)
{
   if(root == NULL)
     return;

   display(root -> get_left());
   root -> display();
   display(root -> get_right());
       
   return;
}


// Wrapper to display one monster in BST
void list::Display_One()
{
  char temp[30];

  cout << "Please enter the monster name you'd like to Display" << endl;
  cin.get(temp,30,'\n');
  cin.ignore(100,'\n');

  display_monster(root,temp);
  return;
}



// Recursive function to display one monster in BST
void list::display_monster(bst_node * & root, char temp_name[])
{
   if(root == NULL)
     return;

   display_monster(root -> get_left(),temp_name);

   int result = root -> compare(root,temp_name);

   if(result == 3)
   {
     cout << "\n**Monster Found**" << endl;
     root -> display();
     return;
   }

   display_monster(root -> get_right(),temp_name);
    
   return;


}

	 
// Wrapper Function to Delete the BST
void list::Delete()
{
  remove_all(root);
}

	 

// Recursive Function to delte the BST
void list::remove_all(bst_node * & root)
{
  if(root == NULL)
   return;
  
  remove_all(root -> get_left());
  remove_all(root -> get_right());
  
  root -> remove();
  delete root;
  root = NULL;

  return;
}





// DLL Implementation for List Class


// Wrappr Function
// Removes a node from the DLL
void list::remove_ability(int monster_type, int id)
{
   --monster_type; 
   int counter = 0;
   node * & current = table[monster_type];
   remove_ability(current,monster_type,id,counter);
}



// Recursive Function to remove Node from DLL
void list::remove_ability(node * & head, int monster_type, int id, int & counter)
{
  node * removal;
  node * forward;
  int results;

  if(head == NULL)
  {
    cout << "\nMonster Not Found!" << endl;
    return;
  }

  if(counter == 0)
  {
    results = head -> compare(id);

    if(results == 1)
    {
      forward = head -> get_next();
      removal = head;
      head = forward;
      removal -> remove();
      delete removal;
      return;
    }
  }

  node * hold = head -> get_prev();

  if(counter != 0)
  {
    results = head -> compare(id);
    if(results == 1)
    {
      forward = head -> get_next();
      removal = head;
      head = forward;
      removal -> remove();

      if(head != NULL)
        head -> set_prev(hold);
      
      delete removal;
      return;
    }
  }
  ++counter;
  remove_ability(head->get_next(),monster_type,id,counter);

}



// Wrapper for Displaying DLL
void list::Display_Abilities()
{

  for(int i=0;i<4;++i)
  {
    node * current = table[i]; 
    display_abilities(current);
  }

}


	  
void list::Display_One_DLL()
{
  char temp[30];
  int flag = 0;

  cout << "Please enter the attack name you'd like to Display" << endl;
  cin.get(temp,30,'\n');
  cin.ignore(100,'\n');
  
  for(int i=0;i<4;++i)
  {
    node * current = table[i]; 
    display_ability(current,temp,flag);

    if(flag == 1)
     return;
  }

}

	  
void list::display_ability(node * & head, char temp_name[], int & flag)
{
  int result = 0;
  if(head == NULL)
    return ;

  result = head -> compare_name(temp_name);

  if(result == 1)
  {
    head -> display();
    flag = 1;
    return;
  }

  node * forward = head -> get_next();

  display_ability(forward,temp_name,flag);


}



// Recursive for Displaying DLL
void list::display_abilities(node * & head)
{
  if(head == NULL)
    return ;

  head -> display();

  node * forward = head -> get_next();

  display_abilities(forward);
}



// Adds a node to the DLL
// Wrapper Function
void list::Add_abilities(int monster_type, int id)
{
  --monster_type;
  node  * & current = table[monster_type];
  add_abilities(current,monster_type,id);
}



// Recursive function to add to DLL
void list::add_abilities(node * & head, int monster_type, int id)
{
  node * end  = NULL;
  node * temp;

  if(head == NULL)
  {
    head = new node;
    head -> set_next(end);
    head -> set_prev(end);
    head -> read(id);
    return;
  }

  node * hold = head;
  
  if(head -> get_next() == NULL)
  {
    temp = new node;
    head -> set_next(temp);
    temp -> set_next(end);
    temp -> set_prev(hold);
    temp -> read(id);
    return;
  }

  add_abilities(head->get_next(),monster_type,id);
}





// Deletes the entire DLL
void list::remove_all_wrap_ability()
{
  for(int i=0;i<4;++i)
  {
    if(table[i] != NULL)
    {
      node * & current  = table[i];

      if(current != NULL)
        remove_all_ability(current);
    }
  }
}



// Removes all nodes from DLL
void list::remove_all_ability(node * & head)
{
  if(head == NULL)
    return;

  node * hold = head -> get_next();
  head -> remove();

  if(head != NULL)
    delete head;

  head = hold;

  remove_all_ability(hold);
  return;
}

	    



//**********************
// DLL Node Class Implementation
//**********************


// Constructor
node::node()
{
  next = NULL;
  previous = NULL;
}
	     


// Deconstructor
node::~node()
{


}



// Delete Node
void node::remove()
{
  delete [] attack;
  delete [] defense;
}
	     


int node::compare_name(char temp[])
{
  if(strcmp(attack,temp) == 0)
    return 1;
  
  return 0;
}


// Checks for a match
int node::compare(int id)
{
  if(monster_id == id)
    return 1;
  return 0;

}


// Used for traversing the DLL	      
node  * & node::grab()
{
  return current;
}
	  



// Displays Node data
void node::display()
{
  cout << "Main Attack: " << attack <<  endl;
  cout << "Main Defense: " << defense <<  endl;
}



// Get next pointer
node * & node::get_next()
{
  return next;
}



// Get previous pointer
node * & node::get_prev()
{
  return previous;
}


// Sets next pointer
void node::set_next(node * & temp)
{
  this -> next = temp;
}


// Sets previous pointer
void node::set_prev(node * & temp)
{
  this -> previous = temp;
}



// Sets the data inside of the DLL node
// Main attack and Main defense data from the monster
// Assigns id to assign it to a specific monster
void node::read(int id)
{
  char temp_name[30];
  char temp_type[30];
	
  cout << "Please enter that monster's Main Attack Move" << endl;
  cin.get(temp_name,30,'\n');
  cin.ignore(100,'\n');
	
  cout << "Please enter that monster's Main Defense Move" << endl;
  cin.get(temp_type,30,'\n');
  cin.ignore(100,'\n');

  attack  = new char[strlen(temp_name) + 1];
  strcpy(attack,temp_name);


  defense  = new char[strlen(temp_type) + 1];
  strcpy(defense,temp_type);

  monster_id = id;
}


	 

