// Channer Bok Program 3 data structure .h file
// This file houses the class interfaces for the 
// Array of DLL node class, the BST node class,
// and the list class to manage them. 



#include"program.h"

// Doubly Linked List Node class
class node
{
      public: 
	      node();                      // Constructor
	      ~node();                     // Deconstructor

	      node * & get_next();         // Get next pointer
	      node * & get_prev();         // Get previous pointer
	      node  * & grab();            // Used for traversal
	      void set_next(node * & temp);// Set next pointer
	      void set_prev(node * & temp);// Set previous pointer

	      void read(int id);           // Copies data from monster into node
	      int compare(int id);         // Compares nodes for search
	      int compare_name(char temp[]);// Compares nodes for displaying 
	      void display();              // Displays data in node
	      void remove();               // Delete data in node

   protected:
	   char * attack;  // Monsters Main attack
	   char * defense; // Monsters Main defense
	   int monster_id; // Used to track monster in DLL
	   node * next;    // Next pointer
	   node * previous;// Previous pointer
	   node * current; // Pointer used for traversal
};



// Binary Search Tree Node Class
class bst_node
{
    public:
	bst_node();                            // Constructor
	~bst_node();                           // Deconstructor

	bst_node * & get_left();               // Get left pointer
	bst_node * & get_right();              // Get right pointer
	void set_left(bst_node * & new_left);  // Set left pointer
	void set_right(bst_node * & new_right);// Set right pointer

	void display();                        // Displays data in node
	void remove();                         // Deletes data in node
	void copy(bst_node * & copy);          // Copies data in one node to another
	int compare(bst_node * & root, char new_name[]); // Compares data in node for traversing BST
        void read(char new_name[], char new_type[], int id, int monster_type); // Copies data from monster into node


    protected:
	char * name;     // Monster's name
	char * type;     // Monser Type
	int monster_id;  // Monster ID
	bst_node * left; // Left Pointer
	bst_node * right;// Right Pointer

};



// Manages the BST and DLL nodes and the programs data structures
class list
{
  public:
	  list(); // Constructor
	  ~list();// Deconstructor
         
	  // BST Class Functions
	  // Wrapper Functions
	  void Add_Monster(char new_name[], char new_type[], int id, int monster_type);             // Wrapper for adding a node
	  void remove_monster_wrapper(char temp_name[], int id);                                    // Wrapper for removing node
	  void Display_Monster();                                                                   // Wrapper for displaying BST
	  void Display_One();
	  void Delete();

          // Recursive Functions
          void add(bst_node * & root, char new_name [], char new_type[], int id, int monster_type); // Recursive for adding a node
	  void display(bst_node * root);                                                            // Recursive for displaying BST
	  void remove_monster(bst_node * & root, char new_name[],int id);                           // Recursive for removing node
	  void display_monster(bst_node * & root, char temp_name[]);
	  void remove_all(bst_node * & root);


	  // DLL Class Functions
	  // Wrapper Functions
	  void Add_abilities(int monster_type, int id);               // Add a node to DLL
	  void remove_ability(int monster_type, int id);              // Delete one node
	  void remove_all_wrap_ability();                             // Delete all nodes
	  void Display_Abilities();                                   // Display all nodes
	  void Display_One_DLL();
	


	  // Recursive Functions 
	  void add_abilities(node * & head, int monster_type, int id);                 // Add a node
	  void remove_ability(node * & head, int monster_type, int id, int & counter); // Remove one node
	  void display_abilities(node * & head);                                       // Display all nodes
	  void remove_all_ability(node * & head);                                      // Remove all nodes
	  void display_ability(node * & head, char temp_name[], int & flag);



   protected:
	  node ** table;  // Array of DLL pointers
	  bst_node * root;// Root of the BST
	  int array_size; // Size of array of DLL

};
