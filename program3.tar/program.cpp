// Channer Bok Program 3 monster class .cpp file
// This file implements that base class monster as well as
// the derived classed dragon,vampire,werewolf, and zombie.
// It implements all of their member functions as well as all
// of the operator overloading being done of the classes.


#include"structure.h"
            
//**********************
// Monster Implementation
//**********************


// Constructor
monster::monster()
{
  name = NULL;
  color = NULL;
  attack = NULL;
  hp = 0;
  strength = 0;
  defense = 0;
}


// Deconstructor
monster::~monster()
{
  delete [] name;
  delete [] color;
  delete [] attack;
}

	  
// Relational operator
int operator < (monster & object, monster & object_two)
{
  if(object.strength > object_two.strength)
    return 1;

  else
    return 0;

  return 5;
}


// Used for Copying for BST
void monster::grab(char temp_name[], char temp_type[])
{
  strcpy(temp_name,name);

}


// Non-Equality Operator
int monster::operator != (const monster & object) const
{
  if(strcmp(name,object.name) == 0)
   return 0;

  if(strcmp(color,object.color) == 0)
   return 0;

  if(hp == object.hp)
    return 0;

  if(strength == object.strength)
    return 0;

  return 1;
}



// Used for Data structures to track monsters
int monster::find(char temp_name[], int & temp_id)
{
  if(name == NULL)
    return 0;

  if(strcmp(name,temp_name) == 0)
  {
    temp_id = monster_id;
    return 1;
  }

  return 0;
}




// Obtains input from user to fill in monster data
void monster::add(int id)
{
  char temp[50];  

  cout << "\nPlease enter monster name" << endl;
  cin.get(temp,50,'\n');
  cin.ignore(100,'\n');
  name = new char[strlen(temp) + 1];
  strcpy(name,temp);


  cout << "\nPlease enter monster color" << endl;
  cin.get(temp,50,'\n');
  cin.ignore(100,'\n');
  color = new char[strlen(temp) + 1];
  strcpy(color,temp);

  cout << "Please enter the monster hp" << endl;
  cin >> hp;
  cin.ignore(100,'\n');


  cout << "Please enter the monster strength rating" << endl;
  cin >> strength;
  cin.ignore(100,'\n');

  cout << "Please enter the monster defense rating" << endl;
  cin >> defense;
  cin.ignore(100,'\n');

  monster_id = id;
}



// Compares object to passed array
int monster::compare(char new_name[])
{
  if(strcmp(new_name,name) < 0)
    return 0;

  if(strcmp(new_name,name) > 0)
    return 1;

  if(strcmp(new_name,name) == 0)
    return 2;

  return 10;
}
	   


// Copy Constructor
// Used for copying with operator overloading
void monster::set_monster(const monster & new_monster, int modifier)
{
  name = new char[strlen(new_monster.name) + 1];
  strcpy(name, new_monster.name);
  
  color = new char[strlen(new_monster.color) + 1];
  strcpy(color,new_monster.color);

  strength = new_monster.strength;

  hp = new_monster.hp;
  strength = new_monster.strength;
  defense = new_monster.defense;

  strength += modifier;
  defense += modifier;
  hp += modifier;
}


 
// Supplements Derived Class Plus Equal operator overloading
monster::monster(const monster & source, int modifier)
{
  hp += modifier; 
}


// Copy Function
void monster::set_monster(const monster & new_monster)
{
  name = new char[strlen(new_monster.name) + 1];
  strcpy(name, new_monster.name);
  
  color = new char[strlen(new_monster.color) + 1];
  strcpy(color,new_monster.color);

  strength = new_monster.strength;

  hp = new_monster.hp;
  strength = new_monster.strength;
  defense = new_monster.defense;
}



// Used to display Monster Data-None Overloaded Form
void monster::display() const
{
  cout << "Monster name: " << name << endl
       << "Monster color: " << color << endl 
       << "hp = " << hp << endl
       << "Strength = " << strength << endl
       << "Defense = " << defense << endl;
}


// Addition Operator Overloading-Alters Strength/Defense Data
monster monster::operator + (const int modifier) 
{
  this -> strength += modifier;
  this -> defense += modifier;

  return *this;
}


// Plus Equals Operator Overloading-Alters Hitpoint Data
monster & monster::operator += (const int strength_mod)
{
  hp += strength_mod;
  return *this;
}



// Equality Operator Overloading
int monster::operator == (const monster & object) const
{
  if(strcmp(name,object.name) != 0)
   return 0;

  if(strcmp(color,object.color) != 0)
   return 0;

  if(hp != object.hp)
    return 0;

  if(strength != object.strength)
    return 0;

  return 1;
}



// Deallocates Dynamic Memory For Monster
void monster::remove()
{
  delete [] name;
  name = NULL;
  delete [] color;
  color = NULL;

  hp = 0;
  strength = 0;
  defense = 0;
}




// Assignment Operator Overloading
monster& monster:: operator = (const monster & source)
{
  if(this == &source)
   return *this; 

  if(name != NULL)
  {
    delete [] name;
  }

  if(color != NULL)
  {
    delete [] color;
  }

  name = new char[strlen(source.name) + 1];
  strcpy(name, source.name);
  
  color = new char[strlen(source.color) + 1];
  strcpy(color,source.color);
  
  strength = source.strength;
  defense = source.defense;
  hp = source.hp;
  return *this;
}



//**********************
// Dragon Implementation
//**********************



// Constructor
dragon::dragon()
{
  type = NULL;
}


dragon::~dragon()
{
  delete [] type;
}


dragon::dragon(const dragon & source)
{
  type = new char[20];
  strcpy(type,source.type);
  monster::set_monster(source);
}



// Copy Constructor
dragon::dragon(const dragon & new_dragon, int modifier)
{
  type = new char[strlen(new_dragon.type) + 1];
  strcpy(type,new_dragon.type);
  monster::set_monster(new_dragon,modifier);
}



// Deallocates Dyanmic Memory
void dragon::remove()
{
  monster::remove();
  delete [] type;
  type = NULL;
}


// Addition Operator Overloading
dragon dragon::operator + (const int modifier) const
{
  dragon temp;
  temp = *this;
  temp.monster::operator + (modifier);
  
  return dragon(temp);
}



// Wrapper to get Base Class Data
void dragon::grab(char temp_name[], char temp_type[])
{
  monster::grab(temp_name,temp_type);
}

	  

// Wrapper to call base class function for Searching
int dragon::find(char temp_name[], int & temp_id)
{
  int result = monster::find(temp_name,temp_id);
  return result;
}



// Obtains Dragon Specific Data and calls base class input function
void dragon::add(int id)
{
  char temp[30];

  monster::add(id);
  cout << "Enter the type of dragon" << endl;
  cin.get(temp,30,'\n');
  cin.ignore(100,'\n');

  type = new char[strlen(temp) + 1];
  strcpy(type,temp);
}




// Output Operator Overloading
// Calls Base Class Function
ostream & operator << (ostream & O, const dragon & object)
{
  if(object.name != NULL)   
    object.monster::display();
  
  if(object.type != NULL)
    O << "Dragon Type: " << object.type << endl;

  return O;
}



// Assignment Operator Overloading
// Calls Base Class Function
dragon & dragon::operator = (const dragon & object)
{
  monster::operator = (object);
  type = new char[strlen(object.type) + 1];
  strcpy(type, object.type);
  return *this;
}


// Plus Equals Op Overloading
// Calls Base Class Function
dragon & dragon::operator += (const int strength_mod) 
{
  monster::operator += (strength_mod);
  return *this;
}


	   
	  
// Equality Op Oveloading w/ zombie object
// Calls Base Class Function
int dragon::operator == (const class zombie & object) const
{
  int result = monster::operator==(object);
  
  if(result == 1)
    return 1;

   return 0;
}



// Eqaulity Op overloading w/ werewolf object
// Calls Base Class Function
int dragon::operator == (const class werewolf & object) const
{
  int result = monster::operator==(object);
  
  if(result == 1)
    return 1;

   return 0;
}




// Eqaulity Op overloading w/ vampire object
// Calls Base Class Function
int dragon::operator == (const vampire & object) const
{
  int result = monster::operator==(object);
  
  if(result == 1)
    return 1;
 
  return 0;
}



// Eqaulity Operator
// Calls Base Class Function
int dragon::operator == (const dragon & object) const
{
  int result = monster::operator==(object);

  if(strcmp(type,object.type) != 0)
    return 0;

  else if(result == 1)
    return 1;
  
  return 0;
}




// Non-Eqaulity Operator
// Calls Base Class Function
int dragon::operator != (const dragon & object) const
{
  int result = monster::operator!=(object);

  if(strcmp(type,object.type) == 0)
    return 0;

  else if(result == 1)
    return 1;
  
  return 0;
}




//**********************
// Vampire Impelentation
//**********************


// Constructor
vampire::vampire()
{
  type = NULL;
}



// Destructor
vampire::~vampire()
{
  delete [] type;
}


	  
// Copy Constr.
vampire::vampire(const vampire & source)
{
  type = new char[20];
  strcpy(type,source.type);
  monster::set_monster(source);
}




// Wrapper To grab data for searching
void vampire::grab(char temp_name[], char temp_type[])
{
  monster::grab(temp_name,temp_type);
}



// Deallocates Dynamic Memory
// Calls Base Class Function
void vampire::remove()
{
  monster::remove();
  delete [] type;
  type = NULL;
}



// Wrapper to obtain data for searching
// Calls Base Class Function
int vampire::find(char temp_name[], int & temp_id)
{
 int result = monster::find(temp_name,temp_id);
 return result;
}


// Obtains Vampire Data
// Calls Base Class Function
void vampire::add(int id)
{
  char temp[30];

  monster::add(id);

  cout << "Enter the type of vampire" << endl;
  cin.get(temp,30,'\n');
  cin.ignore(100,'\n');

  type = new char[strlen(temp) + 1];
  strcpy(type,temp);

}



// Output Operator Overloading
// Calls Base Class Function
ostream & operator << (ostream & O,vampire & object)
{
  if(object.name != NULL)   
    object.monster::display();

  if(object.type != NULL)
     O << "vampire Type: " << object.type << endl;

  return O;
}



// Addition Operator Oveloading	  
// Calls Base Class Function
vampire vampire::operator + (const int modifier) const
{
  vampire temp;
  temp = *this;
  temp.monster::operator + (modifier);
  return vampire(temp);
}



// Copy Constructor
// Calls Base Class Function
vampire::vampire(const vampire & new_vampire, int modifier)
{
  type = new char[strlen(new_vampire.type) + 1];
  strcpy(type,new_vampire.type);
  monster::set_monster(new_vampire,modifier);
}

	  

// Assignment Operator Overloading
// Calls Base Class Function
vampire & vampire::operator = (const vampire & object)
{
  monster::operator = (object);
  type = new char[strlen(object.type) + 1];
  strcpy(type, object.type);
  return *this;
}



// Plus Equals Operator Overlaoding
// Calls Base Class Function
vampire & vampire::operator += (const int strength_mod) 
{
  monster::operator += (strength_mod);
  return *this;
}



// Equality Op Overloading w/ dragon object	   
// Calls Base Class Function
int vampire::operator == (const dragon & object) const
{
  int result = monster::operator==(object);
  if(result == 1)
    return 1;
  return 0;
}



// Equality op w/ zombie object
// Calls Base Class Function
int vampire::operator == (const class zombie & object) const
{
  int result = monster::operator==(object);
  if(result == 1)
    return 1;
  return 0;
}


// Equality op w/ werewolf object
// Calls Base Class Function
int vampire::operator == (const class werewolf & object) const
{
  int result = monster::operator==(object);
  if(result == 1)
    return 1;
  return 0;
}



// Equality Operator
// Calls Base Class Function
int vampire::operator == (const vampire & object) const
{
  int result = monster::operator==(object);

  if(strcmp(type,object.type) != 0)
    return 0;

  else if(result == 1)
    return 1;

   return 0;
}



// None-Equality Operator
// Calls Base Class Function
int vampire::operator != (const vampire & object) const
{
  int result = monster::operator!=(object);

  if(strcmp(type,object.type) == 0)
    return 0;

  else if(result == 1)
    return 1;

   return 0;
}




//**********************
// Werewolf Implementation
//**********************



// Constructor
werewolf::werewolf()
{
  type = NULL; 
}


// Destructor
werewolf::~werewolf()
{
  delete [] type;
}




// Copy Constructor
// Calls Base Class Function
werewolf::werewolf(const werewolf & new_werewolf, int modifier)
{
  type = new char[strlen(new_werewolf.type) + 1];
  strcpy(type,new_werewolf.type);
  monster::set_monster(new_werewolf,modifier);
}



// Copy Constructor
// Calls Base Class Function
werewolf::werewolf(const werewolf & source)
{
  type = new char[20];
  strcpy(type,source.type);
  monster::set_monster(source);
}



// Used for Search
// Calls Base Class Function
void werewolf::grab(char temp_name[], char temp_type[])
{
  monster::grab(temp_name,temp_type);
}



// Used for Copying for Search
// Calls Base Class Function
int werewolf::find(char temp_name[], int & temp_id)
{
 int result = monster::find(temp_name,temp_id);
 return result;
}



// Deallocates Dynamic Memory
// Calls Base Class Function
void werewolf::remove()
{
  monster::remove();
  delete [] type;
  type = NULL;
}



// Prompts user fore werewolf data
// Calls Base Class Function
void werewolf::add(int id)
{
  char temp[30];

  monster::add(id);

  cout << "Enter the type of werewolf" << endl;
  cin.get(temp,30,'\n');
  cin.ignore(100,'\n');

  type = new char[strlen(temp) + 1];
  strcpy(type,temp);
}

	 


// Addition operator
// Calls Base Class Function
werewolf werewolf::operator + (const int modifier) const
{
  werewolf temp;
  temp = *this;
  temp.monster::operator + (modifier);
  return werewolf(temp);
}





// Assignment Operator	   
// Calls Base Class Function
werewolf & werewolf::operator = (const werewolf & object)
{
  monster::operator = (object);
  type = new char[strlen(object.type) + 1];
  strcpy(type, object.type);
  return *this;
}




// Output operator
// Calls Base Class Function
ostream & operator << (ostream & O,werewolf & object)
{
  
  if(object.name != NULL)   
    object.monster::display();

  if(object.type != NULL)
    O << "Werewolf Type: " << object.type << endl;

  return O;
}




// Plus Equals Operator
// Calls Base Class Function
werewolf & werewolf::operator += (const int strength_mod) 
{
  monster::operator += (strength_mod);
  return *this;
}


	  

// Equality Operator w/ vampire object
// Calls Base Class Function
int werewolf::operator == (const vampire & object) const
{
  int result = monster::operator==(object);
  
  if(result == 1)
    return 1;
  return 0;
}

   

// Equality Operator w/ dragon object
// Calls Base Class Function
int werewolf::operator == (const dragon & object) const
{
  int result = monster::operator==(object);

  if(result == 1)
    return 1;
  return 0;
}
	   


// Equality Operator w/ zombie object
// Calls Base Class Function
int werewolf::operator == (const zombie & object) const
{
  int result = monster::operator==(object);
  
  if(result == 1)
    return 1;

  return 0;
}




// Equality Operator
// Calls Base Class Function
int werewolf::operator == (const werewolf & object) const
{
  int result = monster::operator==(object);

  if(strcmp(type,object.type) != 0)
    return 0;

  else if(result == 1)
    return 1;

   return 0;
}



// Non-Equality Operaotor
// Calls Base Class Function
int werewolf::operator != (const werewolf & object) const
{
  int result = monster::operator!=(object);

  if(strcmp(type,object.type) == 0)
    return 0;

  else if(result == 1)
    return 1;

   return 0;
}




//**********************
// Zombie Implementation
//**********************



// Constructor
zombie::zombie()
{
  type = NULL; 
}


// Destructor
zombie::~zombie()
{
  delete [] type;
}




// Copy COnstructor
// Calls Base Class Function
zombie::zombie(const zombie & source)
{
  type = new char[20];
  strcpy(type,source.type);
  monster::set_monster(source);
}



// Copy Constructor
// Calls Base Class Function
zombie::zombie(const zombie & new_zombie, int modifier)
{
  type = new char[strlen(new_zombie.type) + 1];
  strcpy(type,new_zombie.type);
  monster::set_monster(new_zombie,modifier);
}



// Used for Search
// Calls Base Class Function
void zombie::grab(char temp_name[], char temp_type[])
{
  monster::grab(temp_name,temp_type);
}




// Used to copy data for Search	   
// Calls Base Class Function
int zombie::find(char temp_name[], int & temp_id)
{
  int result = monster::find(temp_name,temp_id);
  return result;
}



// Obtains Zombie data from user
// Calls Base Class Function
void zombie::add(int id)
{
  char temp[30];

  monster::add(id);

  cout << "Enter the type of zombie" << endl;
  cin.get(temp,30,'\n');
  cin.ignore(100,'\n');

  type = new char[strlen(temp) + 1];
  strcpy(type,temp);
}




// Addition Operator
// Calls Base Class Function
zombie zombie::operator + (const int modifier) const
{
  zombie temp;
  temp = *this;
  temp.monster::operator + (modifier);
  return zombie(temp);
}



// Assignment Operator	   
// Calls Base Class Function
zombie & zombie::operator = (const zombie & object)
{

  monster::operator = (object);
  type = new char[strlen(object.type) + 1];
  strcpy(type, object.type);
  return *this;
}



// Plus equals operator
// Calls Base Class Function
zombie & zombie::operator += (const int strength_mod)
{
  monster::operator += (strength_mod);
  return *this;
}


	   
// Equality Op w/ werewolf object
// Calls Base Class Function
int zombie::operator == (const werewolf & object) const
{
  int result = monster::operator==(object);
  
  if(result == 1)
    return 1;
  return 0;
}



// Equality Operator w/ vampire object
// Calls Base Class Function
int zombie::operator == (const vampire & object) const
{
  int result = monster::operator==(object);
  
  if(result == 1)
    return 1;
  return 0;
}




// Equality op w/ dragon object
// Calls Base Class Function
int zombie::operator == (const dragon & object) const
{
  int result = monster::operator==(object);
  
  if(result == 1)
    return 1;
  return 0;
}




// Equality Op. w/ zombie object
// Calls Base Class Function
int zombie::operator == (const zombie & object) const
{
  int result = monster::operator==(object);

  if(strcmp(type,object.type) != 0)
    return 0;

  else if(result == 1)
    return 1;

   return 0;
}




// Non-Equality Operator
// Calls Base Class Function
int zombie::operator != (const zombie & object) const
{
  int result = monster::operator!=(object);

  if(strcmp(type,object.type) == 0)
    return 0;

  else if(result == 1)
    return 1;

   return 0;
}



// Output Operator Overloading
// Calls Base Class Function
ostream & operator << (ostream & O,zombie & object)
{
  
  if(object.name != NULL)   
    object.monster::display();

  if(object.type != NULL)
    O << "Zombie Type: " << object.type << endl;

  return O;
}



// Deallocates Dynamic Memory
// Calls Base Class Function
void zombie::remove()
{
  monster::remove();
  delete [] type;
  type = NULL;
}






